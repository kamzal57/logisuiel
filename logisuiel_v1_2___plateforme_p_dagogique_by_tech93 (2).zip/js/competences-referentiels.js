document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const subjectTabs = document.querySelectorAll('#subjects-tabs .tab-btn');
    const referentialsList = document.querySelector('.referentials-list');
    const competencesList = document.getElementById('competences-list');
    const filterLevel = document.getElementById('filter-level');
    const searchCompetence = document.getElementById('search-competence');
    const btnAddReferential = document.getElementById('btn-add-referential');
    const btnAddCompetence = document.getElementById('btn-add-competence');
    const addReferentialModal = document.getElementById('add-referential-modal');
    const addCompetenceModal = document.getElementById('add-competence-modal');
    const editCompetenceModal = document.getElementById('edit-competence-modal');
    const addReferentialForm = document.getElementById('add-referential-form');
    const addCompetenceForm = document.getElementById('add-competence-form');
    const editCompetenceForm = document.getElementById('edit-competence-form');
    const competenceReferential = document.getElementById('competence-referential');
    const editCompetenceReferential = document.getElementById('edit-competence-referential');
    const closeButtons = document.querySelectorAll('.close-btn');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    const pageInfo = document.getElementById('page-info');

    // State
    let referentials = [];
    let competences = [];
    let currentSubject = 'all';
    let currentLevel = 'all';
    let currentSearch = '';
    let selectedReferentialId = null;
    let currentPage = 1;
    const itemsPerPage = 10;
    let currentEditCompetenceId = null;

    // Initialize
    init();

    function init() {
        loadData();
        renderReferentials();
        renderCompetences();
        populateReferentialDropdowns();
        setupEventListeners();
    }

    function loadData() {
        referentials = JSON.parse(localStorage.getItem('referentials_data') || '[]');
        competences = JSON.parse(localStorage.getItem('competences_data') || '[]');
    }

    function saveData() {
        localStorage.setItem('referentials_data', JSON.stringify(referentials));
        localStorage.setItem('competences_data', JSON.stringify(competences));
        exportToGithub();
    }

    function setupEventListeners() {
        // Subject tabs
        subjectTabs.forEach(tab => {
            tab.addEventListener('click', function() {
                currentSubject = this.getAttribute('data-subject');
                // Update active tab
                subjectTabs.forEach(t => t.classList.remove('active'));
                this.classList.add('active');
                // Reset page
                currentPage = 1;
                renderReferentials();
                renderCompetences();
            });
        });

        // Level filter
        filterLevel.addEventListener('change', function() {
            currentLevel = this.value;
            currentPage = 1;
            renderReferentials();
            renderCompetences();
        });

        // Search input
        searchCompetence.addEventListener('input', function() {
            currentSearch = this.value.toLowerCase();
            currentPage = 1;
            renderCompetences();
        });

        // Add referential button
        btnAddReferential.addEventListener('click', function() {
            openAddReferentialModal();
        });

        // Add competence button
        btnAddCompetence.addEventListener('click', function() {
            openAddCompetenceModal();
        });

        // Form submissions
        addReferentialForm.addEventListener('submit', function(e) {
            e.preventDefault();
            addReferential();
        });

        addCompetenceForm.addEventListener('submit', function(e) {
            e.preventDefault();
            addCompetence();
        });

        editCompetenceForm.addEventListener('submit', function(e) {
            e.preventDefault();
            updateCompetence();
        });

        // Close modals
        closeButtons.forEach(button => {
            button.addEventListener('click', function() {
                closeAllModals();
            });
        });

        // Cancel buttons
        document.getElementById('cancel-add-referential').addEventListener('click', closeAllModals);
        document.getElementById('cancel-add-competence').addEventListener('click', closeAllModals);
        document.getElementById('cancel-edit-competence').addEventListener('click', closeAllModals);

        // Pagination
        prevPageBtn.addEventListener('click', function() {
            if (currentPage > 1) {
                currentPage--;
                renderCompetences();
            }
        });

        nextPageBtn.addEventListener('click', function() {
            const filteredItems = getFilteredCompetences();
            const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
            
            if (currentPage < totalPages) {
                currentPage++;
                renderCompetences();
            }
        });
    }

    function openAddReferentialModal() {
        addReferentialForm.reset();
        addReferentialModal.classList.add('active');
    }

    function openAddCompetenceModal() {
        addCompetenceForm.reset();
        populateReferentialDropdowns();
        
        // If a referential is selected in the UI, pre-select it in the form
        if (selectedReferentialId) {
            competenceReferential.value = selectedReferentialId;
        }
        
        addCompetenceModal.classList.add('active');
    }

    function openEditCompetenceModal(competenceId) {
        const competence = competences.find(c => c.id === competenceId);
        if (!competence) return;
        
        currentEditCompetenceId = competenceId;
        
        // Populate form fields
        populateReferentialDropdowns();
        document.getElementById('edit-competence-referential').value = competence.referentialId;
        document.getElementById('edit-competence-code').value = competence.code;
        document.getElementById('edit-competence-name').value = competence.name;
        document.getElementById('edit-competence-domain').value = competence.domain || '';
        document.getElementById('edit-competence-description').value = competence.description || '';
        
        editCompetenceModal.classList.add('active');
    }

    function closeAllModals() {
        addReferentialModal.classList.remove('active');
        addCompetenceModal.classList.remove('active');
        editCompetenceModal.classList.remove('active');
    }

    function populateReferentialDropdowns() {
        // Clear existing options
        while (competenceReferential.options.length > 1) {
            competenceReferential.remove(1);
        }
        
        while (editCompetenceReferential.options.length > 1) {
            editCompetenceReferential.remove(1);
        }
        
        // Add referentials to the dropdowns
        referentials.forEach(ref => {
            const option1 = document.createElement('option');
            option1.value = ref.id;
            option1.textContent = `${ref.name} (${getSubjectName(ref.subject)} - ${getLevelName(ref.level)})`;
            competenceReferential.appendChild(option1);
            
            const option2 = document.createElement('option');
            option2.value = ref.id;
            option2.textContent = `${ref.name} (${getSubjectName(ref.subject)} - ${getLevelName(ref.level)})`;
            editCompetenceReferential.appendChild(option2);
        });
    }

    function addReferential() {
        const name = document.getElementById('referential-name').value;
        const subject = document.getElementById('referential-subject').value;
        const level = document.getElementById('referential-level').value;
        const description = document.getElementById('referential-description').value;
        
        const newReferential = {
            id: Date.now().toString(),
            name,
            subject,
            level,
            description,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        referentials.push(newReferential);
        saveData();
        
        // Reset form and close modal
        addReferentialForm.reset();
        closeAllModals();
        
        // Refresh UI
        renderReferentials();
        populateReferentialDropdowns();
    }

    function addCompetence() {
        const referentialId = document.getElementById('competence-referential').value;
        const code = document.getElementById('competence-code').value;
        const name = document.getElementById('competence-name').value;
        const domain = document.getElementById('competence-domain').value;
        const description = document.getElementById('competence-description').value;
        
        if (!referentialId) {
            alert('Veuillez sélectionner un référentiel.');
            return;
        }
        
        // Find the referential to get subject and level
        const referential = referentials.find(ref => ref.id === referentialId);
        if (!referential) return;
        
        const newCompetence = {
            id: Date.now().toString(),
            referentialId,
            code,
            name,
            domain,
            description,
            subject: referential.subject,
            level: referential.level,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
        };
        
        competences.push(newCompetence);
        saveData();
        
        // Reset form and close modal
        addCompetenceForm.reset();
        closeAllModals();
        
        // Refresh UI
        renderCompetences();
    }

    function updateCompetence() {
        const referentialId = document.getElementById('edit-competence-referential').value;
        const code = document.getElementById('edit-competence-code').value;
        const name = document.getElementById('edit-competence-name').value;
        const domain = document.getElementById('edit-competence-domain').value;
        const description = document.getElementById('edit-competence-description').value;
        
        if (!referentialId) {
            alert('Veuillez sélectionner un référentiel.');
            return;
        }
        
        // Find the referential to get subject and level
        const referential = referentials.find(ref => ref.id === referentialId);
        if (!referential) return;
        
        // Find and update the competence
        const competenceIndex = competences.findIndex(c => c.id === currentEditCompetenceId);
        if (competenceIndex === -1) return;
        
        competences[competenceIndex] = {
            ...competences[competenceIndex],
            referentialId,
            code,
            name,
            domain,
            description,
            subject: referential.subject,
            level: referential.level,
            updatedAt: new Date().toISOString()
        };
        
        saveData();
        
        // Close modal and refresh
        closeAllModals();
        renderCompetences();
    }

    function renderReferentials() {
        referentialsList.innerHTML = '';
        
        // Filter referentials by subject
        const filteredReferentials = referentials.filter(ref => {
            if (currentSubject === 'all') return true;
            if (currentSubject === 'other' && !['MATH', 'FRA', 'HG', 'SVT', 'PHY'].includes(ref.subject)) return true;
            return ref.subject === currentSubject;
        }).filter(ref => {
            if (currentLevel === 'all') return true;
            return ref.level === currentLevel;
        });
        
        if (filteredReferentials.length === 0) {
            referentialsList.innerHTML = '<div class="text-center">Aucun référentiel trouvé</div>';
            return;
        }
        
        filteredReferentials.forEach(ref => {
            // Count competences for this referential
            const competenceCount = competences.filter(comp => comp.referentialId === ref.id).length;
            
            const card = document.createElement('div');
            card.className = `referential-card ${selectedReferentialId === ref.id ? 'active' : ''}`;
            card.dataset.id = ref.id;
            
            card.innerHTML = `
                <div class="referential-header">
                    <div class="referential-title">${ref.name}</div>
                    <div class="referential-subject subject-${ref.subject}">${getSubjectName(ref.subject)}</div>
                </div>
                <div class="referential-subtitle">${getLevelName(ref.level)}</div>
                <div class="referential-stats">
                    <div>${competenceCount} compétence${competenceCount !== 1 ? 's' : ''}</div>
                    <div>Créé le ${formatDate(ref.createdAt)}</div>
                </div>
                <div class="referential-actions">
                    <button class="action-btn edit" title="Modifier" data-id="${ref.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete" title="Supprimer" data-id="${ref.id}">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>
            `;
            
            // Add event listener to select the referential
            card.addEventListener('click', function(e) {
                if (!e.target.closest('.action-btn')) {
                    selectedReferentialId = ref.id === selectedReferentialId ? null : ref.id;
                    renderReferentials();
                    renderCompetences();
                }
            });
            
            // Add event listeners for action buttons
            const editBtn = card.querySelector('.action-btn.edit');
            const deleteBtn = card.querySelector('.action-btn.delete');
            
            editBtn.addEventListener('click', () => editReferential(ref.id));
            deleteBtn.addEventListener('click', () => confirmDeleteReferential(ref.id));
            
            referentialsList.appendChild(card);
        });
    }

    function getFilteredCompetences() {
        return competences.filter(comp => {
            // Filter by selected referential
            if (selectedReferentialId && comp.referentialId !== selectedReferentialId) {
                return false;
            }
            
            // Filter by subject
            if (currentSubject !== 'all') {
                if (currentSubject === 'other' && !['MATH', 'FRA', 'HG', 'SVT', 'PHY'].includes(comp.subject)) {
                    // Include in "other" category
                } else if (comp.subject !== currentSubject) {
                    return false;
                }
            }
            
            // Filter by level
            if (currentLevel !== 'all' && comp.level !== currentLevel) {
                return false;
            }
            
            // Filter by search
            if (currentSearch) {
                const searchableText = `${comp.code} ${comp.name} ${comp.domain || ''}`.toLowerCase();
                return searchableText.includes(currentSearch);
            }
            
            return true;
        });
    }

    function getPaginatedCompetences() {
        const filteredItems = getFilteredCompetences();
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        
        return filteredItems.slice(start, end);
    }

    function updatePagination() {
        const filteredItems = getFilteredCompetences();
        const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
        
        pageInfo.textContent = `Page ${currentPage} sur ${totalPages || 1}`;
        
        prevPageBtn.disabled = currentPage <= 1;
        nextPageBtn.disabled = currentPage >= totalPages;
    }

    function renderCompetences() {
        competencesList.innerHTML = '';
        
        const paginatedCompetences = getPaginatedCompetences();
        
        if (paginatedCompetences.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="6" class="text-center">Aucune compétence trouvée</td>';
            competencesList.appendChild(row);
        } else {
            paginatedCompetences.forEach(comp => {
                const referential = referentials.find(ref => ref.id === comp.referentialId);
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td><span class="competence-code">${comp.code}</span></td>
                    <td>${comp.name}</td>
                    <td class="competence-domain">${comp.domain || '-'}</td>
                    <td>${getLevelName(comp.level)}</td>
                    <td>${getSubjectName(comp.subject)}</td>
                    <td class="actions-cell">
                        <button class="action-btn view" title="Voir les détails" data-id="${comp.id}">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="action-btn edit" title="Modifier" data-id="${comp.id}">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete" title="Supprimer" data-id="${comp.id}">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </td>
                `;
                
                // Add event listeners for action buttons
                const viewBtn = row.querySelector('.action-btn.view');
                const editBtn = row.querySelector('.action-btn.edit');
                const deleteBtn = row.querySelector('.action-btn.delete');
                
                viewBtn.addEventListener('click', () => viewCompetence(comp.id));
                editBtn.addEventListener('click', () => openEditCompetenceModal(comp.id));
                deleteBtn.addEventListener('click', () => confirmDeleteCompetence(comp.id));
                
                competencesList.appendChild(row);
            });
        }
        
        // Update pagination
        updatePagination();
    }

    function editReferential(referentialId) {
        const referential = referentials.find(ref => ref.id === referentialId);
        if (!referential) return;
        
        // For now, just use a simple prompt
        const newName = prompt('Nom du référentiel:', referential.name);
        if (newName !== null) {
            referential.name = newName;
            referential.updatedAt = new Date().toISOString();
            saveData();
            renderReferentials();
            populateReferentialDropdowns();
        }
    }

    function confirmDeleteReferential(referentialId) {
        // Check if there are competences using this referential
        const hasCompetences = competences.some(comp => comp.referentialId === referentialId);
        
        let message = 'Êtes-vous sûr de vouloir supprimer ce référentiel ?';
        if (hasCompetences) {
            message = 'Ce référentiel contient des compétences qui seront également supprimées. Voulez-vous continuer ?';
        }
        
        if (confirm(message)) {
            deleteReferential(referentialId);
        }
    }

    function deleteReferential(referentialId) {
        // Remove the referential
        referentials = referentials.filter(ref => ref.id !== referentialId);
        
        // Remove associated competences
        competences = competences.filter(comp => comp.referentialId !== referentialId);
        
        // Reset selected referential if needed
        if (selectedReferentialId === referentialId) {
            selectedReferentialId = null;
        }
        
        saveData();
        renderReferentials();
        renderCompetences();
        populateReferentialDropdowns();
    }

    function viewCompetence(competenceId) {
        const competence = competences.find(comp => comp.id === competenceId);
        if (!competence) return;
        
        // Find the referential
        const referential = referentials.find(ref => ref.id === competence.referentialId);
        
        // Build the message
        let message = `Code: ${competence.code}\n`;
        message += `Nom: ${competence.name}\n`;
        message += `Domaine: ${competence.domain || 'Non spécifié'}\n`;
        message += `Référentiel: ${referential ? referential.name : 'Inconnu'}\n`;
        message += `Discipline: ${getSubjectName(competence.subject)}\n`;
        message += `Niveau: ${getLevelName(competence.level)}\n`;
        
        if (competence.description) {
            message += `\nDescription:\n${competence.description}`;
        }
        
        // Show in an alert for now
        alert(message);
    }

    function confirmDeleteCompetence(competenceId) {
        if (confirm('Êtes-vous sûr de vouloir supprimer cette compétence ?')) {
            deleteCompetence(competenceId);
        }
    }

    function deleteCompetence(competenceId) {
        competences = competences.filter(comp => comp.id !== competenceId);
        saveData();
        renderCompetences();
    }

    // Helper functions
    function getSubjectName(subjectCode) {
        switch (subjectCode) {
            case 'MATH': return 'Mathématiques';
            case 'FRA': return 'Français';
            case 'HG': return 'Histoire-Géographie';
            case 'SVT': return 'SVT';
            case 'PHY': return 'Physique-Chimie';
            case 'LV1': return 'Langue Vivante 1';
            case 'LV2': return 'Langue Vivante 2';
            case 'EPS': return 'EPS';
            case 'TECH': return 'Technologie';
            case 'ART': return 'Arts Plastiques';
            case 'MUS': return 'Éducation Musicale';
            case 'OTHER': return 'Autre';
            default: return subjectCode;
        }
    }

    function getLevelName(levelCode) {
        switch (levelCode) {
            case '6': return '6ème';
            case '5': return '5ème';
            case '4': return '4ème';
            case '3': return '3ème';
            case '2': return '2nde';
            case '1': return '1ère';
            case 'T': return 'Terminale';
            case 'cycle3': return 'Cycle 3';
            case 'cycle4': return 'Cycle 4';
            case 'lycee': return 'Lycée';
            default: return levelCode;
        }
    }

    function formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('fr-FR');
    }

    // Export data to GitHub
    async function exportToGithub() {
        try {
            // Import the functions from gists-sync.js
            const module = await import('./gists-sync.js').catch(e => {
                console.error('Error importing gists-sync.js:', e);
                return null;
            });
            
            if (!module) return;
            
            const { saveToGist } = module;
            
            // Collect all data
            const dataToUpload = {
                userData: JSON.parse(localStorage.getItem('user_data') || '{}'),
                schedules: JSON.parse(localStorage.getItem('imported_calendars') || '[]'),
                classes: JSON.parse(localStorage.getItem('classes_data') || '[]'),
                evaluations: JSON.parse(localStorage.getItem('evaluations_data') || '[]'),
                students: JSON.parse(localStorage.getItem('students_data') || '[]'),
                grades: JSON.parse(localStorage.getItem('grades_data') || '{}'),
                groups: JSON.parse(localStorage.getItem('groups_data') || '[]'),
                referentials: referentials,
                competences: competences
            };
            
            // Save to GitHub
            await saveToGist(dataToUpload);
            
            // Update last sync date
            localStorage.setItem('last_sync_date', new Date().toISOString());
            
            console.log('Competency data exported to GitHub Gists successfully');
        } catch (error) {
            console.error('Error exporting competency data to GitHub:', error);
        }
    }
});