document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const evalsList = document.getElementById('evaluations-list');
    const filterClass = document.getElementById('filter-class');
    const filterPeriod = document.getElementById('filter-period');
    const filterSubject = document.getElementById('filter-subject');
    const btnAddEval = document.getElementById('btn-add-eval');
    const evalModal = document.getElementById('eval-modal');
    const gradesModal = document.getElementById('grades-modal');
    const evalForm = document.getElementById('eval-form');
    const closeButtons = document.querySelectorAll('.close-btn');
    const cancelEvalBtn = document.getElementById('cancel-eval');
    const cancelGradesBtn = document.getElementById('cancel-grades');
    const saveGradesBtn = document.getElementById('save-grades');
    const modalTitle = document.getElementById('modal-title');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    const pageInfo = document.getElementById('page-info');

    // Clear hardcoded options, keeping only the "all" option
    while (filterClass.options.length > 1) {
        filterClass.remove(1);
    }

    // State
    let evaluations = JSON.parse(localStorage.getItem('evaluations_data') || '[]');
    
    let grades = JSON.parse(localStorage.getItem('grades_data') || '{}');
    
    // Students data by class - empty objects to start
    const students = {};
    
    // New Load students
    function loadStudents(){
        const studentData = JSON.parse(localStorage.getItem('students_data') || '[]');
        studentData.forEach(student => {
            if(!students[student.class]){
                students[student.class] = [];
            }
            students[student.class].push(student);
        });
    }
    
    // Pagination
    let currentPage = 1;
    const itemsPerPage = 10;
    
    // Filter settings
    let currentFilter = { class: 'all', period: 'all', subject: 'all' };
    
    // Current editing state
    let currentEvalId = null;
    
    // Initialize
    initialize();
    
    function initialize() {
        // Render the initial evaluations list
        renderEvaluations();
        
        // Set up event listeners
        setupEventListeners();

        // Populate class filter
        populateClassFilter();
    }
    
    function setupEventListeners() {
        // Filter changes
        filterClass.addEventListener('change', function() {
            currentFilter.class = this.value;
            currentPage = 1;
            renderEvaluations();
        });
        
        filterPeriod.addEventListener('change', function() {
            currentFilter.period = this.value;
            currentPage = 1;
            renderEvaluations();
        });
        
        filterSubject.addEventListener('change', function() {
            currentFilter.subject = this.value;
            currentPage = 1;
            renderEvaluations();
        });
        
        // Pagination
        prevPageBtn.addEventListener('click', function() {
            if (currentPage > 1) {
                currentPage--;
                renderEvaluations();
            }
        });
        
        nextPageBtn.addEventListener('click', function() {
            const filteredItems = getFilteredEvaluations();
            const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
            
            if (currentPage < totalPages) {
                currentPage++;
                renderEvaluations();
            }
        });
        
        // Add evaluation button
        btnAddEval.addEventListener('click', function() {
            openCreateEvalModal();
        });
        
        // Close modals
        closeButtons.forEach(button => {
            button.addEventListener('click', function() {
                closeAllModals();
            });
        });
        
        // Cancel buttons
        cancelEvalBtn.addEventListener('click', function() {
            closeAllModals();
        });
        
        cancelGradesBtn.addEventListener('click', function() {
            closeAllModals();
        });
        
        // Form submission
        evalForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveEvaluation();
        });
        
        // Save grades
        saveGradesBtn.addEventListener('click', function() {
            saveGradesData();
        });
    }
    
    function getFilteredEvaluations() {
        return evaluations.filter(eval => {
            // Apply class filter
            if (currentFilter.class !== 'all' && eval.class !== currentFilter.class) {
                return false;
            }
            
            // Apply period filter
            if (currentFilter.period !== 'all' && eval.period !== currentFilter.period) {
                return false;
            }
            
            // Apply subject filter
            if (currentFilter.subject !== 'all' && eval.subject !== currentFilter.subject) {
                return false;
            }
            
            return true;
        });
    }
    
    function getPaginatedEvaluations() {
        const filteredItems = getFilteredEvaluations();
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        
        return filteredItems.slice(start, end);
    }
    
    function updatePagination() {
        const filteredItems = getFilteredEvaluations();
        const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
        
        pageInfo.textContent = `Page ${currentPage} sur ${totalPages || 1}`;
        
        prevPageBtn.disabled = currentPage <= 1;
        nextPageBtn.disabled = currentPage >= totalPages;
    }
    
    function renderEvaluations() {
        const paginatedItems = getPaginatedEvaluations();
        
        // Clear current list
        evalsList.innerHTML = '';
        
        // Add each evaluation to the list
        paginatedItems.forEach(eval => {
            const row = document.createElement('tr');
            
            // Format date
            const date = new Date(eval.date);
            const formattedDate = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
            
            // Status label
            let statusLabel = '';
            switch(eval.status) {
                case 'draft':
                    statusLabel = '<span class="eval-status draft">Brouillon</span>';
                    break;
                case 'in-progress':
                    statusLabel = '<span class="eval-status in-progress">En cours</span>';
                    break;
                case 'completed':
                    statusLabel = '<span class="eval-status completed">Terminé</span>';
                    break;
            }
            
            row.innerHTML = `
                <td>${formattedDate}</td>
                <td>${eval.title}</td>
                <td>${eval.class}</td>
                <td>${eval.subjectName}</td>
                <td>${eval.periodName}</td>
                <td>${eval.coefficient}</td>
                <td>${eval.maxPoints} pts</td>
                <td>${statusLabel}</td>
                <td class="actions-cell">
                    <button class="action-btn grades" title="Saisir les notes" data-id="${eval.id}">
                        <i class="fas fa-clipboard-list"></i>
                    </button>
                    <button class="action-btn edit" title="Modifier" data-id="${eval.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete" title="Supprimer" data-id="${eval.id}">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </td>
            `;
            
            // Add event listeners for action buttons
            const editBtn = row.querySelector('.action-btn.edit');
            const deleteBtn = row.querySelector('.action-btn.delete');
            const gradesBtn = row.querySelector('.action-btn.grades');
            
            editBtn.addEventListener('click', function() {
                const evalId = parseInt(this.getAttribute('data-id'));
                openEditEvalModal(evalId);
            });
            
            deleteBtn.addEventListener('click', function() {
                const evalId = parseInt(this.getAttribute('data-id'));
                confirmDeleteEvaluation(evalId);
            });
            
            gradesBtn.addEventListener('click', function() {
                const evalId = parseInt(this.getAttribute('data-id'));
                openGradesModal(evalId);
            });
            
            evalsList.appendChild(row);
        });
        
        // Update pagination
        updatePagination();
    }
    
    function openCreateEvalModal() {
        // Reset form
        evalForm.reset();
        
        // Set modal title
        modalTitle.textContent = 'Créer une évaluation';
        
        // Reset current eval ID
        currentEvalId = null;
        
        // Show modal
        evalModal.classList.add('active');
    }
    
    function openEditEvalModal(evalId) {
        // Find the evaluation
        const evaluation = evaluations.find(eval => eval.id === evalId);
        if (!evaluation) return;
        
        // Set current eval ID
        currentEvalId = evalId;
        
        // Set modal title
        modalTitle.textContent = 'Modifier l\'évaluation';
        
        // Populate form fields
        document.getElementById('eval-title').value = evaluation.title;
        document.getElementById('eval-date').value = evaluation.date;
        document.getElementById('eval-class').value = evaluation.class;
        document.getElementById('eval-subject').value = evaluation.subject;
        document.getElementById('eval-period').value = evaluation.period;
        document.getElementById('eval-coefficient').value = evaluation.coefficient;
        document.getElementById('eval-max-points').value = evaluation.maxPoints;
        document.getElementById('eval-description').value = evaluation.description || '';
        
        // Show modal
        evalModal.classList.add('active');
    }
    
    function saveEvaluation() {
        // Get form values
        const title = document.getElementById('eval-title').value;
        const date = document.getElementById('eval-date').value;
        const classValue = document.getElementById('eval-class').value;
        const subject = document.getElementById('eval-subject').value;
        const period = document.getElementById('eval-period').value;
        const coefficient = parseFloat(document.getElementById('eval-coefficient').value);
        const maxPoints = parseInt(document.getElementById('eval-max-points').value);
        const description = document.getElementById('eval-description').value;
        
        // Get subject name and period name
        const subjectName = document.getElementById('eval-subject').options[document.getElementById('eval-subject').selectedIndex].text;
        const periodName = document.getElementById('eval-period').options[document.getElementById('eval-period').selectedIndex].text;
        
        if (currentEvalId === null) {
            // Create new evaluation
            const newId = Math.max(0, ...evaluations.map(e => e.id)) + 1;
            
            const newEvaluation = {
                id: newId,
                title,
                date,
                class: classValue,
                subject,
                subjectName,
                period,
                periodName,
                coefficient,
                maxPoints,
                status: 'draft',
                description
            };
            
            evaluations.push(newEvaluation);
            
            // Initialize empty grades for this evaluation
            grades[newId] = [];
        } else {
            // Update existing evaluation
            const evaluation = evaluations.find(eval => eval.id === currentEvalId);
            if (evaluation) {
                evaluation.title = title;
                evaluation.date = date;
                evaluation.class = classValue;
                evaluation.subject = subject;
                evaluation.subjectName = subjectName;
                evaluation.period = period;
                evaluation.periodName = periodName;
                evaluation.coefficient = coefficient;
                evaluation.maxPoints = maxPoints;
                evaluation.description = description;
            }
        }
        
        // Save evaluations to local storage
        localStorage.setItem('evaluations_data', JSON.stringify(evaluations));
        
        // Close modal
        closeAllModals();
        
        // Refresh list
        renderEvaluations();
        
        // Export data to GitHub
        exportToGithub();
    }
    
    function confirmDeleteEvaluation(evalId) {
        // In a real app, this would show a confirmation dialog
        if (confirm('Êtes-vous sûr de vouloir supprimer cette évaluation ?')) {
            deleteEvaluation(evalId);
        }
    }
    
    function deleteEvaluation(evalId) {
        // Remove the evaluation from the array
        evaluations = evaluations.filter(eval => eval.id !== evalId);
        
        // Remove associated grades
        delete grades[evalId];
        
        // Save evaluations to local storage
        localStorage.setItem('evaluations_data', JSON.stringify(evaluations));
        localStorage.setItem('grades_data', JSON.stringify(grades)); // Save grades too
        
        // Refresh list
        renderEvaluations();
    }
    
    function openGradesModal(evalId) {
        // Find the evaluation
        const evaluation = evaluations.find(eval => eval.id === evalId);
        if (!evaluation) return;
        
        // Set current eval ID
        currentEvalId = evalId;
        
        // Set modal title
        document.getElementById('grades-modal-title').textContent = `Saisie des notes - ${evaluation.title}`;
        
        // Set evaluation info
        document.getElementById('grade-class').textContent = evaluation.class;
        document.getElementById('grade-subject').textContent = evaluation.subjectName;
        document.getElementById('grade-max').textContent = evaluation.maxPoints;
        document.getElementById('grade-coef').textContent = evaluation.coefficient;
        
        // Load and render the grades list for the student
        loadStudents();
        renderGradesList(evalId, evaluation.maxPoints, evaluation.class);
        
        // Show modal
        gradesModal.classList.add('active');
    }
    
    function renderGradesList(evalId, maxPoints, classValue) {
        const gradesList = document.getElementById('grades-list');
        gradesList.innerHTML = '';
        
        // Load grades data
        grades = JSON.parse(localStorage.getItem('grades_data') || '{}');
        
        // Get or initialize grades for this evaluation
        if (!grades[evalId]) {
            grades[evalId] = [];
        }
        
        // Load student by class
        if (students[classValue]) {
            students[classValue].forEach((student) => {
                let existingGrade = grades[evalId].find(g => g.studentId === student.id);
                if (!existingGrade) {
                    grades[evalId].push({
                        studentId: student.id,
                        firstName: student.firstName,
                        lastName: student.lastName,
                        grade: null,
                        comment: '',
                        absent: false,
                        nonNoted: false
                    });
                }
            });
        }
        
        // Add each student to the list
        grades[evalId].forEach((student, index) => {
            const row = document.createElement('tr');
            row.dataset.studentId = student.studentId;
            
            // Calculate grade out of 20
            const grade20 = student.grade !== null ? ((student.grade / maxPoints) * 20).toFixed(2) : '-';
            
            row.innerHTML = `
                <td>${student.lastName} ${student.firstName}</td>
                <td>
                    <input type="number" class="grade-input" min="0" max="${maxPoints}" step="0.5" 
                           value="${student.grade !== null ? student.grade : ''}" 
                           ${student.absent || student.nonNoted ? 'disabled' : ''}>
                </td>
                <td class="grade-20">${grade20}</td>
                <td>
                    <input type="text" class="comment-input" placeholder="Observation" value="${student.comment || ''}">
                </td>
                <td class="absent-checkbox">
                    <input type="checkbox" id="absent-${index}" class="absent-check" ${student.absent ? 'checked' : ''}>
                </td>
                <td class="non-noted-checkbox">
                    <input type="checkbox" id="non-noted-${index}" class="non-noted-check" ${student.nonNoted ? 'checked' : ''}>
                </td>
            `;
            
            gradesList.appendChild(row);
            
            // Add event listeners
            const gradeInput = row.querySelector('.grade-input');
            const absentCheck = row.querySelector('.absent-check');
            const nonNotedCheck = row.querySelector('.non-noted-check');
            
            gradeInput.addEventListener('change', function() {
                updateGrade20(row, this.value, maxPoints);
            });
            
            absentCheck.addEventListener('change', function() {
                const nonNoted = row.querySelector('.non-noted-check');
                const gradeInput = row.querySelector('.grade-input');
                
                if (this.checked) {
                    nonNoted.checked = false;
                    gradeInput.value = '';
                    gradeInput.disabled = true;
                    row.querySelector('.grade-20').textContent = '-';
                } else {
                    gradeInput.disabled = !nonNoted.checked;
                }
            });
            
            nonNotedCheck.addEventListener('change', function() {
                const absent = row.querySelector('.absent-check');
                const gradeInput = row.querySelector('.grade-input');
                
                if (this.checked) {
                    absent.checked = false;
                    gradeInput.value = '';
                    gradeInput.disabled = true;
                    row.querySelector('.grade-20').textContent = '-';
                } else {
                    gradeInput.disabled = !absent.checked;
                }
            });
        });
        
        // Calculate and display class average
        calculateClassAverage(evalId, maxPoints);
    }
    
    function updateGrade20(row, grade, maxPoints) {
        const grade20Cell = row.querySelector('.grade-20');
        
        if (grade === '' || grade === null) {
            grade20Cell.textContent = '-';
        } else {
            const grade20 = ((parseFloat(grade) / maxPoints) * 20).toFixed(2);
            grade20Cell.textContent = grade20;
        }
    }
    
    function calculateClassAverage(evalId, maxPoints) {
        // Get all valid grades
        const validGrades = grades[evalId]
            .filter(student => student.grade !== null && !student.absent && !student.nonNoted)
            .map(student => parseFloat(student.grade));
        
        // Calculate average
        let average = 0;
        if (validGrades.length > 0) {
            average = validGrades.reduce((sum, grade) => sum + grade, 0) / validGrades.length;
        }
        
        // Calculate average out of 20
        const average20 = (average / maxPoints) * 20;
        
        // Display averages
        document.getElementById('average-points').textContent = average.toFixed(2);
        document.getElementById('average-grade').textContent = average20.toFixed(2);
    }
    
    function saveGradesData() {
        // Get the rows
        const rows = document.querySelectorAll('#grades-list tr');
        
        // Make sure grades for this eval exist
        if (!grades[currentEvalId]) {
            grades[currentEvalId] = [];
        }
        
        // Update grades data
        rows.forEach(row => {
            const studentId = row.dataset.studentId;
            const gradeValue = row.querySelector('.grade-input').value;
            const comment = row.querySelector('.comment-input').value;
            const absent = row.querySelector('.absent-check').checked;
            const nonNoted = row.querySelector('.non-noted-check').checked;
            
            // Find and update the student in the grades array
            const studentGrade = grades[currentEvalId].find(g => g.studentId === studentId);
            if (studentGrade) {
                studentGrade.grade = gradeValue === '' ? null : parseFloat(gradeValue);
                studentGrade.comment = comment;
                studentGrade.absent = absent;
                studentGrade.nonNoted = nonNoted;
            }
        });
        
        // Update evaluation status
        const evaluation = evaluations.find(eval => eval.id === currentEvalId);
        if (evaluation) {
            // Check if all students have grades or are marked absent/non-noted
            const allGraded = grades[currentEvalId].every(g => g.grade !== null || g.absent || g.nonNoted);
            
            if (allGraded) {
                evaluation.status = 'completed';
            } else if (grades[currentEvalId].some(g => g.grade !== null || g.absent || g.nonNoted)) {
                evaluation.status = 'in-progress';
            } else {
                evaluation.status = 'draft';
            }
        }
        
        // Save evaluations to local storage
        localStorage.setItem('evaluations_data', JSON.stringify(evaluations));
        // Save grades data
        localStorage.setItem('grades_data', JSON.stringify(grades));
        
        // Close modal
        closeAllModals();
        
        // Refresh list
        renderEvaluations();
        
        // Export data to GitHub
        exportToGithub();
    }
    
    function closeAllModals() {
        evalModal.classList.remove('active');
        gradesModal.classList.remove('active');
    }
    
    function populateClassFilter() {
        const filterClass = document.getElementById('filter-class');
        const evalClass = document.getElementById('eval-class');
        
        // Load classes from local storage
        const classes = JSON.parse(localStorage.getItem('classes_data') || '[]');
        
        // Clear existing options, keeping only the "all" option in filterClass
        while (filterClass.options.length > 1) {
            filterClass.remove(1);
        }

        // Clear existing options
        while (evalClass.options.length > 0) {
            evalClass.remove(0);
        }
        
        // Add a default selection
        const defaultOption = document.createElement('option');
        defaultOption.value = "";
        defaultOption.textContent = "Sélectionnez";
        evalClass.add(defaultOption);

        // Add classes to both filterClass and evalClass
        classes.forEach(cls => {
            const filterOption = document.createElement('option');
            filterOption.value = cls.id;
            filterOption.textContent = cls.name;
            filterClass.add(filterOption);

            const evalOption = document.createElement('option');
            evalOption.value = cls.id;
            evalOption.textContent = cls.name;
            evalClass.add(evalOption);
        });
    }

    async function exportToGithub() {
        try {
            // Import the functions from gists-sync.js
            const module = await import('./gists-sync.js').catch(e => {
                console.error('Error importing gists-sync.js:', e);
                return null;
            });
            
            if (!module) return;
            
            const { saveToGist } = module;
            
            // Collect all data
            const dataToUpload = {
                userData: JSON.parse(localStorage.getItem('user_data') || '{}'),
                schedules: JSON.parse(localStorage.getItem('imported_calendars') || '[]'),
                classes: JSON.parse(localStorage.getItem('classes_data') || '[]'),
                evaluations: JSON.parse(localStorage.getItem('evaluations_data') || '[]'),
                students: JSON.parse(localStorage.getItem('students_data') || '[]'),
                grades: JSON.parse(localStorage.getItem('grades_data') || '{}')
            };
            
            // Save to GitHub
            await saveToGist(dataToUpload);
            
            // Update last sync date
            localStorage.setItem('last_sync_date', new Date().toISOString());
            
            console.log('Evaluation data exported to GitHub Gists successfully');
        } catch (error) {
            console.error('Error exporting evaluation data to GitHub:', error);
        }
    }
});