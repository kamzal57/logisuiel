document.addEventListener('DOMContentLoaded', function() {
    // Set current date information before initializing
    setCurrentDateInfo();
    
    // Initialize the schedule
    initSchedule();
    
    // Import schedules from GitHub if available
    importSchedulesFromGithub().then(() => {
        // After importing, render the events
        renderEvenementsCalendrier();
    });
    
    // Set up event listeners for schedule controls
    setupScheduleControls();
    
    // Set up iCal import functionality
    setupICalImport();
    
    // Set up JSON import functionality
    setupJSONImport();
    
    // Set up add course functionality
    setupAddCourse();
    
    // Load the default view (weekly)
    showScheduleView('weekly');
});

// Set current date information for the schedule
function setCurrentDateInfo() {
    const now = new Date();
    const currentDay = now.getDay(); // 0 = Sunday, 1 = Monday, ...
    const currentDate = now.getDate();
    
    // Get Monday of the current week
    const monday = new Date(now);
    const daysSinceMonday = currentDay === 0 ? 6 : currentDay - 1;
    monday.setDate(currentDate - daysSinceMonday);
    
    // Get Friday of the current week
    const friday = new Date(monday);
    friday.setDate(monday.getDate() + 4);
    
    // Format dates
    const mondayFormatted = formatDate(monday);
    const fridayFormatted = formatDate(friday);
    
    // Set the current week title
    document.querySelector('.period-navigation h3').textContent = `Semaine du ${mondayFormatted} au ${fridayFormatted}`;
    
    // Set the current day for daily view
    const dayNames = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    const currentDayName = dayNames[currentDay];
    
    // Store current date information globally
    window.currentDateInfo = {
        currentDay,
        currentDate: now,
        monday,
        friday,
        currentDayName,
        currentMonth: now.getMonth(),
        currentYear: now.getFullYear()
    };
}

// Format date as DD/MM/YYYY
function formatDate(date) {
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
}

// Initialize the schedule with events from the data
function initSchedule() {
    // Populate weekly schedule
    populateWeeklySchedule();
    
    // Populate daily schedule
    populateDailySchedule();
    
    // Populate multi-week schedule
    populateMultiWeekSchedule();
}

// Set up the schedule control event listeners
function setupScheduleControls() {
    // Schedule tab switching
    const scheduleTabs = document.querySelectorAll('.schedule-tab');
    scheduleTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            // Remove active class from all tabs
            scheduleTabs.forEach(t => t.classList.remove('active'));
            
            // Add active class to clicked tab
            this.classList.add('active');
            
            // Show the corresponding view
            const view = this.getAttribute('data-view');
            showScheduleView(view);
            
            // Reset current date information when switching views
            setCurrentDateInfo();
        });
    });
    
    // View options switching
    const viewOptions = document.querySelectorAll('.view-option');
    viewOptions.forEach(option => {
        option.addEventListener('click', function() {
            // Remove active class from all options
            viewOptions.forEach(o => o.classList.remove('active'));
            
            // Add active class to clicked option
            this.classList.add('active');
            
            // Update the view based on the option
            const view = this.getAttribute('data-view');
            updateViewType(view);
        });
    });
    
    // Period navigation
    const prevButton = document.querySelector('.period-navigation button:first-child');
    const nextButton = document.querySelector('.period-navigation button:last-child');
    const currentWeekButton = document.querySelector('.period-navigation .current-week-btn');
    const periodTitle = document.querySelector('.period-navigation h3');
    
    prevButton.addEventListener('click', function() {
        // Navigate to previous period
        navigatePeriod('prev', periodTitle);
    });
    
    nextButton.addEventListener('click', function() {
        // Navigate to next period
        navigatePeriod('next', periodTitle);
    });
    
    currentWeekButton.addEventListener('click', function() {
        // Reset to current week
        setCurrentDateInfo();
        const activeTab = document.querySelector('.schedule-tab.active');
        if (activeTab) {
            showScheduleView(activeTab.getAttribute('data-view'));
        } else {
            showScheduleView('weekly');
        }
        // Add this line to render calendar events after resetting to current week
        renderEvenementsCalendrier();
    });
}

// Show the selected schedule view (weekly, daily, multi-week)
function showScheduleView(viewType) {
    // Hide all views
    document.querySelector('.weekly-schedule').style.display = 'none';
    document.querySelector('.daily-schedule').style.display = 'none';
    document.querySelector('.multi-week-schedule').style.display = 'none';
    
    // Use stored current date information
    const { monday, friday, currentDayName, currentMonth, currentYear } = window.currentDateInfo;
    
    // Show the selected view
    if (viewType === 'weekly') {
        document.querySelector('.weekly-schedule').style.display = 'block';
        // Week title is already set by setCurrentDateInfo
    }
    
    // Update the view options visibility
    document.querySelector('.view-options').style.display = 'flex';
}

// Update the view type (day, week, month) - mainly for weekly view
function updateViewType(viewType) {
    console.log(`View type updated to: ${viewType}`);
    // This would update the data display based on the view type
    // For example, showing 5 days, 7 days, or full month
}

// Navigate between periods (previous/next week, day, or month)
function navigatePeriod(direction, titleElement) {
    const currentTitle = titleElement.textContent;
    
    // Sample period navigation - in a real app, this would compute actual dates
    if (currentTitle.includes('Semaine')) {
        // Weekly navigation
        if (direction === 'prev') {
            titleElement.textContent = 'Semaine du 10 au 14 juin 2024';
        } else {
            titleElement.textContent = 'Semaine du 24 au 28 juin 2024';
        }
        // Update the weekly schedule data
        updateWeeklySchedule(direction);
        // Refresh events after updating the week dates
        renderEvenementsCalendrier();
    } else if (currentTitle.includes('Lundi') || 
              currentTitle.includes('Mardi') || 
              currentTitle.includes('Mercredi') || 
              currentTitle.includes('Jeudi') || 
              currentTitle.includes('Vendredi')) {
        // Daily navigation
        const days = ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi'];
        const currentDay = days.findIndex(day => currentTitle.includes(day));
        
        let newDay;
        if (direction === 'prev') {
            newDay = currentDay > 0 ? currentDay - 1 : 4; // Loop to Friday if at Monday
        } else {
            newDay = currentDay < 4 ? currentDay + 1 : 0; // Loop to Monday if at Friday
        }
        
        titleElement.textContent = `${days[newDay]} ${currentDay === newDay ? '24' : '17'} juin 2024`;
        // Update the daily schedule data
        updateDailySchedule(days[newDay]);
    } else if (currentTitle.includes('Juin')) {
        // Monthly navigation
        if (direction === 'prev') {
            titleElement.textContent = 'Mai 2024';
        } else {
            titleElement.textContent = 'Juillet 2024';
        }
        // Update the multi-week schedule data
        updateMultiWeekSchedule(direction);
    }
}

// Populate the weekly schedule with class events
function populateWeeklySchedule() {
    // Sample class events data - empty for a clean start
    const events = [];
    
    // Clear existing events
    const dayColumns = document.querySelectorAll('.day-schedule');
    dayColumns.forEach(column => {
        column.innerHTML = '';
    });
    
    // Add events to the schedule
    events.forEach(event => {
        const eventElement = document.createElement('div');
        eventElement.className = `class-event ${event.subjectClass}`;
        eventElement.style.top = `${(event.startHour - 8) * 60}px`; // 8AM is the start time
        eventElement.style.height = `${event.duration * 60 - 4}px`; // Each hour is 60px, subtract 4px for spacing
        
        eventElement.innerHTML = `
            <div class="event-title">${event.subject}</div>
            <div class="event-location">${event.location}</div>
            <div class="event-class">${event.class}</div>
        `;
        
        // Add a tooltip with event details
        eventElement.title = `${event.subject}\n${event.location}\n${event.class}`;
        
        // Add click event to show more details
        eventElement.addEventListener('click', function() {
            showEventDetails(event);
        });
        
        // Add to the correct day column
        const dayColumn = dayColumns[event.day];
        if (dayColumn) {
            dayColumn.appendChild(eventElement);
        }
    });
}

// Populate the daily schedule view
function populateDailySchedule(day = 'Lundi') {
    // Sample daily schedule data - empty for clean start
    const scheduleData = {
        'Lundi': [],
        'Mardi': [],
        'Mercredi': [],
        'Jeudi': [],
        'Vendredi': []
    };
    
    // Get the day timeline container
    const dayTimeline = document.querySelector('.day-timeline');
    
    // Clear existing events
    dayTimeline.innerHTML = '';
    
    // Add events for the selected day
    scheduleData[day].forEach(event => {
        const eventElement = document.createElement('div');
        eventElement.className = 'timeline-event';
        
        eventElement.innerHTML = `
            <div class="event-time">${event.time}</div>
            <div class="event-details">
                <div class="event-subject ${event.subjectClass}">${event.subject}</div>
                <div class="event-location">${event.location}</div>
                <div class="event-class">${event.class}</div>
            </div>
        `;
        
        dayTimeline.appendChild(eventElement);
    });
}

// Populate the multi-week schedule view
function populateMultiWeekSchedule() {
    // Function emptied
}

// Update weekly schedule when navigating between weeks
function updateWeeklySchedule(direction) {
    // Get current week start date (Monday)
    const currentMonday = window.currentDateInfo.monday;
    
    // Calculate new dates based on direction
    const newMonday = new Date(currentMonday);
    if (direction === 'prev') {
        newMonday.setDate(newMonday.getDate() - 7);
    } else {
        newMonday.setDate(newMonday.getDate() + 7);
    }
    
    // Calculate new Friday
    const newFriday = new Date(newMonday);
    newFriday.setDate(newMonday.getDate() + 4);
    
    // Update stored date information
    window.currentDateInfo.monday = newMonday;
    window.currentDateInfo.friday = newFriday;
    
    // Update the week title
    const mondayFormatted = formatDate(newMonday);
    const fridayFormatted = formatDate(newFriday);
    document.querySelector('.period-navigation h3').textContent = `Semaine du ${mondayFormatted} au ${fridayFormatted}`;
    
    // Clear existing events from weekly view
    const dayColumns = document.querySelectorAll('.day-schedule');
    dayColumns.forEach(column => {
        column.innerHTML = '';
    });
    
    // Render calendar events for the new week
    renderEvenementsCalendrier();
}

// Update daily schedule when navigating between days
function updateDailySchedule(day) {
    populateDailySchedule(day);
}

// Update multi-week schedule when navigating between months
function updateMultiWeekSchedule(direction) {
    // Function emptied
}

// Show detailed information for a schedule event
function showEventDetails(event) {
    // In a real application, this would show a modal with detailed information and options
    console.log('Event details:', event);
    alert(`
        Cours: ${event.subject}
        Classe: ${event.class}
        Salle: ${event.location}
        Durée: ${event.duration} heure(s)
    `);
}

// Set up iCal import functionality
function setupICalImport() {
    const btnImportICal = document.getElementById('btn-import-ical');
    const icalModal = document.getElementById('ical-modal');
    const icalForm = document.getElementById('ical-form');
    const cancelIcal = document.getElementById('cancel-ical');
    const closeBtn = icalModal.querySelector('.close-btn');
    const icalLoading = document.getElementById('ical-loading');
    const icalResult = document.getElementById('ical-result');
    
    // Open modal when import button is clicked
    btnImportICal.addEventListener('click', function() {
        icalModal.classList.add('active');
        // Reset form and result
        icalForm.reset();
        icalResult.style.display = 'none';
        icalLoading.style.display = 'none';
    });
    
    // Close modal
    closeBtn.addEventListener('click', function() {
        icalModal.classList.remove('active');
    });
    
    cancelIcal.addEventListener('click', function() {
        icalModal.classList.remove('active');
    });
    
    // Handle form submission
    icalForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const url = document.getElementById('ical-url').value;
        const name = document.getElementById('ical-name').value;
        const color = document.getElementById('ical-color').value;
        
        // Show loading indicator
        icalForm.style.display = 'none';
        icalLoading.style.display = 'block';
        icalResult.style.display = 'none';
        
        // Fetch iCal data
        importICalFromURL(url, name, color);
    });
}

// Import iCal data from URL
function importICalFromURL(url, calendarName, calendarColor) {
    const icalForm = document.getElementById('ical-form');
    const icalLoading = document.getElementById('ical-loading');
    const icalResult = document.getElementById('ical-result');
    const alertBox = icalResult.querySelector('.alert');
    
    // For demonstration purposes, we'll bypass the actual fetch
    // and simulate a successful response with mock data
    icalLoading.style.display = 'none';
    icalResult.style.display = 'block';
    
    // Create mock event data since we can't fetch external URLs in this environment
    const mockEvents = [
        {
            title: "Cours Mathématiques",
            location: "Salle B204",
            start: new Date(2024, 5, 18, 9, 0), // June 18, 2024 9:00 AM
            end: new Date(2024, 5, 18, 11, 0),  // June 18, 2024 11:00 AM
            description: "Cours de mathématiques importé via iCal"
        },
        {
            title: "Physique-Chimie",
            location: "Laboratoire A105",
            start: new Date(2024, 5, 19, 14, 0), // June 19, 2024 2:00 PM
            end: new Date(2024, 5, 19, 16, 0),   // June 19, 2024 4:00 PM
            description: "Cours de physique-chimie importé via iCal"
        },
        {
            title: "Réunion pédagogique",
            location: "Salle des professeurs",
            start: new Date(2024, 5, 20, 10, 0), // June 20, 2024 10:00 AM
            end: new Date(2024, 5, 20, 12, 0),   // June 20, 2024 12:00 PM
            description: "Réunion avec l'équipe pédagogique"
        }
    ];
    
    // Show success message
    alertBox.className = 'alert success';
    alertBox.innerHTML = `
        <strong>Succès!</strong> ${mockEvents.length} événements importés.
        <p>Le calendrier "${calendarName}" a été importé avec succès.</p>
    `;
    
    // Save mock events to local storage
    saveCalendarData(calendarName, calendarColor, mockEvents);
    
    // Refresh the schedule views with new data
    refreshScheduleWithImportedEvents();
    
    // Add option to close the modal after success
    setTimeout(() => {
        icalForm.style.display = 'block';
        document.getElementById('ical-modal').classList.remove('active');
        // Refresh the views
        renderEvenementsCalendrier();
    }, 2000);
}

// Make sure parseICalData is properly handling the actual iCal format
function parseICalData(icalData) {
    const events = [];
    
    // Simple regex-based parsing (for a production app, use a proper iCal library)
    const eventRegex = /BEGIN:VEVENT([\s\S]*?)END:VEVENT/g;
    const summaryRegex = /SUMMARY:(.*)/;
    const locationRegex = /LOCATION:(.*)/;
    const dtStartRegex = /DTSTART(?:;[^:]*)?:(.*)/;
    const dtEndRegex = /DTEND(?:;[^:]*)?:(.*)/;
    const descriptionRegex = /DESCRIPTION:(.*)/;
    
    let match;
    while (match = eventRegex.exec(icalData)) {
        const eventData = match[1];
        
        // Extract event details
        const summary = (eventData.match(summaryRegex) || [])[1] || '';
        const location = (eventData.match(locationRegex) || [])[1] || '';
        const dtStartStr = (eventData.match(dtStartRegex) || [])[1] || '';
        const dtEndStr = (eventData.match(dtEndRegex) || [])[1] || '';
        const description = (eventData.match(descriptionRegex) || [])[1] || '';
        
        // Parse dates
        let dtStart, dtEnd;
        try {
            dtStart = parseICalDate(dtStartStr);
            dtEnd = parseICalDate(dtEndStr);
        } catch (e) {
            console.error('Error parsing date:', e);
            continue;
        }
        
        // Add event if valid
        if (dtStart && dtEnd) {
            events.push({
                title: summary,
                location: location,
                start: dtStart,
                end: dtEnd,
                description: description
            });
        }
    }
    
    return events;
}

// Parse iCal date format
function parseICalDate(dateStr) {
    // Basic format: YYYYMMDDTHHMMSSZ or YYYYMMDD
    if (!dateStr) return null;
    
    let date;
    if (dateStr.includes('T')) {
        // Date with time
        // Remove any timezone identifier
        dateStr = dateStr.replace('Z', '');
        
        const year = parseInt(dateStr.slice(0, 4));
        const month = parseInt(dateStr.slice(4, 6)) - 1; // JS months are 0-based
        const day = parseInt(dateStr.slice(6, 8));
        const hour = parseInt(dateStr.slice(9, 11));
        const minute = parseInt(dateStr.slice(11, 13));
        const second = parseInt(dateStr.slice(13, 15)) || 0;
        
        date = new Date(year, month, day, hour, minute, second);
    } else {
        // Date only
        const year = parseInt(dateStr.slice(0, 4));
        const month = parseInt(dateStr.slice(4, 6)) - 1; // JS months are 0-based
        const day = parseInt(dateStr.slice(6, 8));
        
        date = new Date(year, month, day);
    }
    
    return date;
}

// Save imported calendar data to local storage
function saveCalendarData(name, color, events) {
    // Get existing calendars or initialize empty array
    const calendars = JSON.parse(localStorage.getItem('imported_calendars') || '[]');
    
    // Add new calendar or update existing one
    const existingIndex = calendars.findIndex(cal => cal.name === name);
    if (existingIndex >= 0) {
        calendars[existingIndex] = { name, color, events };
    } else {
        calendars.push({ name, color, events });
    }
    
    // Save to local storage
    localStorage.setItem('imported_calendars', JSON.stringify(calendars));
}

// Refresh the schedule views with imported events
function refreshScheduleWithImportedEvents() {
    // This function would combine default events with imported events
    // and update all schedule views
    populateWeeklySchedule();
    populateDailySchedule();
    populateMultiWeekSchedule();
}

// Render calendar events in all views
function renderEvenementsCalendrier() {
    // Get all imported calendars
    const calendars = JSON.parse(localStorage.getItem('imported_calendars') || '[]');
    if (calendars.length === 0) return;
    
    // Clear existing events before rendering new ones
    const dayColumns = document.querySelectorAll('.day-schedule');
    dayColumns.forEach(column => {
        column.innerHTML = '';
    });
    
    // Get current week boundaries
    const weekStart = window.currentDateInfo.monday;
    const weekEnd = window.currentDateInfo.friday;
    weekEnd.setHours(23, 59, 59, 999); // End of Friday
    
    // Process all calendars
    calendars.forEach(calendar => {
        // Process the events in each calendar
        if (!calendar.events || !Array.isArray(calendar.events)) return;
        
        calendar.events.forEach(event => {
            // Make sure we can handle both string dates and Date objects
            const startDate = event.start instanceof Date ? event.start : new Date(event.start);
            const endDate = event.end instanceof Date ? event.end : new Date(event.end);
            
            if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) return;
            
            // Only show events in the current week
            if (startDate >= weekStart && startDate <= weekEnd) {
                const dayOfWeek = startDate.getDay(); // 0 = Sunday, 1 = Monday, etc.
                
                // Convert to our 0-indexed week (0 = Monday, 4 = Friday)
                const dayIndex = dayOfWeek === 0 ? 6 : dayOfWeek - 1;
                
                // Only process weekdays (Monday-Friday)
                if (dayIndex < 5) {
                    const startHour = startDate.getHours();
                    const startMinutes = startDate.getMinutes();
                    const endHour = endDate.getHours();
                    const endMinutes = endDate.getMinutes();
                    const duration = (endHour - startHour) + (endMinutes - startMinutes) / 60;
                    
                    if (duration <= 0) return; // Skip invalid events
                    
                    // Create event element
                    const eventElement = document.createElement('div');
                    eventElement.className = 'class-event';
                    // Use calendar color for the event background
                    eventElement.style.backgroundColor = calendar.color || '#3498db';
                    
                    // Calculate position based on hours and minutes
                    const startPosition = (startHour - 8) * 60 + startMinutes;
                    eventElement.style.top = `${startPosition}px`; // 8AM is the start time
                    eventElement.style.height = `${duration * 60 - 4}px`; // Each hour is 60px, subtract 4px for spacing
                    
                    eventElement.innerHTML = `
                        <div class="event-title">${event.title || 'Sans titre'}</div>
                        <div class="event-location">${event.location || 'Aucun lieu'}</div>
                        <div class="event-class">${calendar.name || 'Calendrier'}</div>
                    `;
                    
                    // Add a tooltip with event details
                    eventElement.title = `${event.title || 'Sans titre'}\n${event.location || 'Aucun lieu'}\n${calendar.name || 'Calendrier'}`;
                    
                    // Add to the correct day column
                    const dayColumn = dayColumns[dayIndex];
                    if (dayColumn) {
                        dayColumn.appendChild(eventElement);
                    }
                }
            }
        });
    });
    
    // Also update daily view and multi-week view
    updateDailyViewWithImportedEvents();
    updateMultiWeekViewWithImportedEvents();
}

// Add imported events to daily view
function updateDailyViewWithImportedEvents() {
    const dayTimeline = document.querySelector('.day-timeline');
    const currentDay = document.querySelector('.period-navigation h3').textContent.split(' ')[0];
    
    // Get all imported calendars
    const calendars = JSON.parse(localStorage.getItem('imported_calendars') || '[]');
    if (calendars.length === 0) return;
    
    calendars.forEach(calendar => {
        calendar.events.forEach(event => {
            const eventDate = new Date(event.start);
            const dayOfWeek = eventDate.getDay();
            const dayName = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'][dayOfWeek];
            
            // Only add events for the current displayed day
            if (dayName === currentDay) {
                const startHour = eventDate.getHours();
                const startMinutes = eventDate.getMinutes();
                const endHour = new Date(event.end).getHours();
                const endMinutes = new Date(event.end).getMinutes();
                
                const timeFormatted = `${String(startHour).padStart(2, '0')}:${String(startMinutes).padStart(2, '0')} - ${String(endHour).padStart(2, '0')}:${String(endMinutes).padStart(2, '0')}`;
                
                const eventElement = document.createElement('div');
                eventElement.className = 'timeline-event';
                
                eventElement.innerHTML = `
                    <div class="event-time">${timeFormatted}</div>
                    <div class="event-details">
                        <div class="event-subject" style="color: ${calendar.color};">${event.title}</div>
                        <div class="event-location">${event.location || 'Aucun lieu'}</div>
                        <div class="event-class">${calendar.name}</div>
                    </div>
                `;
                
                dayTimeline.appendChild(eventElement);
            }
        });
    });
}

// Add imported events to multi-week view
function updateMultiWeekViewWithImportedEvents() {
    // Function emptied
}

// Set up JSON import functionality
function setupJSONImport() {
    const btnImportJSON = document.getElementById('btn-import-json');
    const jsonModal = document.getElementById('json-modal');
    const jsonForm = document.getElementById('json-form');
    const cancelJson = document.getElementById('cancel-json');
    const closeBtn = jsonModal.querySelector('.close-btn');
    const jsonResult = document.getElementById('json-result');
    const fileInput = document.getElementById('json-file');
    
    // Open modal when import button is clicked
    btnImportJSON.addEventListener('click', function() {
        jsonModal.classList.add('active');
        // Reset form and result
        jsonForm.reset();
        jsonResult.style.display = 'none';
    });
    
    // Close modal
    closeBtn.addEventListener('click', function() {
        jsonModal.classList.remove('active');
    });
    
    cancelJson.addEventListener('click', function() {
        jsonModal.classList.remove('active');
    });
    
    // Handle file input change
    fileInput.addEventListener('change', function() {
        // Update file name display
        const fileNameDisplay = document.getElementById('file-name-display');
        if (this.files && this.files[0]) {
            fileNameDisplay.textContent = this.files[0].name;
        } else {
            fileNameDisplay.textContent = "Aucun fichier sélectionné";
        }
    });
    
    // Handle form submission
    jsonForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const file = fileInput.files[0];
        const calendarName = document.getElementById('json-name').value;
        const calendarColor = document.getElementById('json-color').value;
        
        if (!file) {
            // Show error if no file is selected
            jsonResult.style.display = 'block';
            const alertBox = jsonResult.querySelector('.alert');
            alertBox.className = 'alert error';
            alertBox.textContent = 'Veuillez sélectionner un fichier JSON';
            return;
        }
        
        // Read the file
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                // Parse JSON
                const events = JSON.parse(e.target.result);
                
                // Check if it's valid format
                if (!Array.isArray(events)) {
                    throw new Error('Le format du fichier JSON est invalide. Un tableau d\'événements est attendu.');
                }
                
                // Save the imported events
                saveCalendarData(calendarName, calendarColor, parseJSONEvents(events));
                
                // Show success message
                jsonResult.style.display = 'block';
                const alertBox = jsonResult.querySelector('.alert');
                alertBox.className = 'alert success';
                alertBox.innerHTML = `
                    <strong>Succès!</strong> ${events.length} événements importés.
                    <p>Le calendrier "${calendarName}" a été importé avec succès.</p>
                `;
                
                // Refresh the schedule views with new data
                refreshScheduleWithImportedEvents();
                
                // Close the modal after a delay
                setTimeout(() => {
                    jsonModal.classList.remove('active');
                    // Refresh the views
                    renderEvenementsCalendrier();
                }, 2000);
                
            } catch (error) {
                // Show error message
                jsonResult.style.display = 'block';
                const alertBox = jsonResult.querySelector('.alert');
                alertBox.className = 'alert error';
                alertBox.innerHTML = `
                    <strong>Erreur!</strong> Impossible d'importer le calendrier.
                    <p>${error.message}</p>
                `;
            }
        };
        
        reader.readAsText(file);
    });
}

// Parse JSON events to our internal format
function parseJSONEvents(jsonEvents) {
    return jsonEvents.map(event => {
        // Parse dates from ISO 8601 format
        const startDate = new Date(event.Starts);
        const endDate = new Date(event.Ends);
        
        // Extract class, teacher, etc. from description if available
        let classInfo = '';
        let teacherInfo = '';
        
        if (event.Description) {
            const descLines = event.Description.split('\n');
           !descLines.every(line => {
                if (line.startsWith('Classe :')) {
                    classInfo = line.replace('Classe :', '').trim();
                } else if (line.startsWith('Professeur :')) {
                    teacherInfo = line.replace('Professeur :', '').trim();
                }
            });
        }
        
        return {
            title: event.Title || 'Sans titre',
            location: event.Location || 'Aucun lieu',
            start: startDate,
            end: endDate,
            description: event.Description || '',
            class: classInfo,
            teacher: teacherInfo
        };
    });
}

// Import schedules from GitHub
async function importSchedulesFromGithub() {
    try {
        // Import the functions from gists-sync.js
        const module = await import('./gists-sync.js').catch(e => {
            console.error('Error importing gists-sync.js:', e);
            return null;
        });
        
        if (!module) return;
        
        const { fetchFromGist } = module;
        
        // Fetch data from GitHub
        const githubData = await fetchFromGist();
        
        if (githubData && githubData.schedules && Array.isArray(githubData.schedules)) {
            console.log(`Found ${githubData.schedules.length} schedules from GitHub`);
            
            // Save schedules to localStorage
            localStorage.setItem('imported_calendars', JSON.stringify(githubData.schedules));
            
            // Refresh the views with imported events
            renderEvenementsCalendrier();
        }
    } catch (error) {
        console.error('Error importing schedules from GitHub:', error);
    }
}

// Set up add course functionality
function setupAddCourse() {
    const btnAddCourse = document.getElementById('btn-add-course');
    const addCourseModal = document.getElementById('add-course-modal');
    const addCourseForm = document.getElementById('add-course-form');
    const cancelAddCourse = document.getElementById('cancel-add-course');
    const closeBtn = addCourseModal.querySelector('.close-btn');
    
    // Load classes into select
    populateCourseClassSelect();
    
    // Open modal when add course button is clicked
    btnAddCourse.addEventListener('click', function() {
        addCourseModal.classList.add('active');
        // Reset form
        addCourseForm.reset();
    });
    
    // Close modal
    closeBtn.addEventListener('click', function() {
        addCourseModal.classList.remove('active');
    });
    
    cancelAddCourse.addEventListener('click', function() {
        addCourseModal.classList.remove('active');
    });
    
    // Handle form submission
    addCourseForm.addEventListener('submit', function(e) {
        e.preventDefault();
        addCourse();
    });
}

// Populate class select in add course form
function populateCourseClassSelect() {
    const courseClassSelect = document.getElementById('course-class');
    
    // Clear existing options except the default one
    while (courseClassSelect.options.length > 1) {
        courseClassSelect.remove(1);
    }
    
    // Load classes from localStorage
    const classes = JSON.parse(localStorage.getItem('classes_data') || '[]');
    
    // Add classes to select
    classes.forEach(cls => {
        const option = document.createElement('option');
        option.value = cls.id;
        option.textContent = cls.name;
        courseClassSelect.appendChild(option);
    });
}

// Add a new course to the schedule
function addCourse() {
    const subject = document.getElementById('course-subject').value;
    const subjectName = document.getElementById('course-subject').options[document.getElementById('course-subject').selectedIndex].text;
    const subjectColor = document.getElementById('course-subject').options[document.getElementById('course-subject').selectedIndex].dataset.color;
    const classId = document.getElementById('course-class').value;
    const className = document.getElementById('course-class').options[document.getElementById('course-class').selectedIndex].text;
    const room = document.getElementById('course-room').value;
    const day = parseInt(document.getElementById('course-day').value);
    const startTime = document.getElementById('course-start').value;
    const endTime = document.getElementById('course-end').value;
    
    // Validate times
    if (startTime >= endTime) {
        alert('L\'heure de fin doit être après l\'heure de début');
        return;
    }
    
    // Create a new event object
    const newEvent = {
        title: subjectName,
        location: room,
        class: className,
        subjectClass: subject,
        color: subjectColor,
        // Create Date objects for the event
        start: createDateFromTimeString(startTime, day),
        end: createDateFromTimeString(endTime, day)
    };
    
    // Get existing calendars or create a new one
    const calendars = JSON.parse(localStorage.getItem('imported_calendars') || '[]');
    
    // Look for a default calendar or create one
    let defaultCalendar = calendars.find(cal => cal.name === 'Mes cours');
    if (!defaultCalendar) {
        defaultCalendar = {
            name: 'Mes cours',
            color: '#3498db',
            events: []
        };
        calendars.push(defaultCalendar);
    }
    
    // Add the event to the calendar
    defaultCalendar.events.push(newEvent);
    
    // Save calendars back to localStorage
    localStorage.setItem('imported_calendars', JSON.stringify(calendars));
    
    // Close the modal
    document.getElementById('add-course-modal').classList.remove('active');
    
    // Refresh the schedule view
    renderEvenementsCalendrier();
    
    // Export to GitHub
    exportToGithub();
}

// Create a Date object from time string and day of week
function createDateFromTimeString(timeString, dayOfWeek) {
    // Get current date info from the window object
    const { monday } = window.currentDateInfo || { monday: new Date() };
    
    // Create a new date based on the Monday of the current week
    const date = new Date(monday);
    
    // Add days to get to the selected day (0 = Monday, 4 = Friday)
    date.setDate(date.getDate() + dayOfWeek);
    
    // Set the time
    const [hours, minutes] = timeString.split(':').map(num => parseInt(num));
    date.setHours(hours, minutes, 0, 0);
    
    return date;
}

// Export to GitHub
async function exportToGithub() {
    try {
        // Import the functions from gists-sync.js
        const module = await import('./gists-sync.js').catch(e => {
            console.error('Error importing gists-sync.js:', e);
            return null;
        });
        
        if (!module) return;
        
        const { saveToGist } = module;
        
        // Collect all data
        const dataToUpload = {
            userData: JSON.parse(localStorage.getItem('user_data') || '{}'),
            schedules: JSON.parse(localStorage.getItem('imported_calendars') || '[]'),
            classes: JSON.parse(localStorage.getItem('classes_data') || '[]'),
            evaluations: JSON.parse(localStorage.getItem('evaluations_data') || '[]'),
            students: JSON.parse(localStorage.getItem('students_data') || '[]'),
            grades: JSON.parse(localStorage.getItem('grades_data') || '{}')
        };
        
        // Save to GitHub
        await saveToGist(dataToUpload);
        
        // Update last sync date
        localStorage.setItem('last_sync_date', new Date().toISOString());
        
        console.log('Course data exported to GitHub Gists successfully');
    } catch (error) {
        console.error('Error exporting course data to GitHub:', error);
    }
}