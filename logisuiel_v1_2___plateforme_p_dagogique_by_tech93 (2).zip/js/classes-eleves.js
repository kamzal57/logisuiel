document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const viewButtons = document.querySelectorAll('.view-btn');
    const studentsList = document.getElementById('students-list');
    const studentsGrid = document.getElementById('students-grid');
    const classFilter = document.getElementById('filter-class');
    const searchInput = document.getElementById('search-students');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    const pageInfo = document.getElementById('page-info');
    const btnAddClass = document.getElementById('btn-add-class');
    const btnAddStudent = document.getElementById('btn-add-student');
    const addClassModal = document.getElementById('add-class-modal');
    const addStudentModal = document.getElementById('add-student-modal');
    const addClassForm = document.getElementById('add-class-form');
    const addStudentForm = document.getElementById('add-student-form');
    const cancelAddClass = document.getElementById('cancel-add-class');
    const cancelAddStudent = document.getElementById('cancel-add-student');
    const studentClassSelect = document.getElementById('student-class');
    const closeButtons = document.querySelectorAll('.close-btn');

    // Classes data - empty array
    let classes = [];

    // Students data - empty array
    let students = [];

    // Current state
    let currentView = 'list';
    let currentFilter = 'all';
    let currentSearch = '';
    let currentPage = 1;
    const itemsPerPage = 10;

    // Initialize the view
    function init() {
        loadData(); // Ensure we load the most recent data
        renderStudents();
        setupEventListeners();
    }

    // Setup event listeners
    function setupEventListeners() {
        // View toggle
        viewButtons.forEach(button => {
            button.addEventListener('click', function() {
                viewButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                
                const view = this.getAttribute('data-view');
                currentView = view;
                
                document.querySelectorAll('.students-view').forEach(view => {
                    view.classList.remove('active');
                });
                
                document.querySelector(`.${view}-view`).classList.add('active');
                
                renderStudents();
            });
        });

        // Class filter
        classFilter.addEventListener('change', function() {
            currentFilter = this.value;
            currentPage = 1;
            renderStudents();
        });

        // Search input
        searchInput.addEventListener('input', function() {
            currentSearch = this.value.toLowerCase();
            currentPage = 1;
            renderStudents();
        });

        // Pagination
        prevPageBtn.addEventListener('click', function() {
            if (currentPage > 1) {
                currentPage--;
                renderStudents();
            }
        });

        nextPageBtn.addEventListener('click', function() {
            const filteredStudents = getFilteredStudents();
            const totalPages = Math.ceil(filteredStudents.length / itemsPerPage);
            
            if (currentPage < totalPages) {
                currentPage++;
                renderStudents();
            }
        });

        // Add class button
        btnAddClass.addEventListener('click', function() {
            openAddClassModal();
        });

        // Add student button
        btnAddStudent.addEventListener('click', function() {
            openAddStudentModal();
        });
        
        // Form submission (Add Class)
        addClassForm.addEventListener('submit', function(e) {
            e.preventDefault();
            addClass();
        });
        
        // Form submission (Add Student)
        addStudentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            addStudent();
        });

        // Close modals
        closeButtons.forEach(button => {
            button.addEventListener('click', function() {
                closeAllModals();
            });
        });
        
        // Cancel add class
        cancelAddClass.addEventListener('click', function() {
            closeAllModals();
        });
        
        // Cancel add student
        cancelAddStudent.addEventListener('click', function() {
            closeAllModals();
        });
    }
    
    //Open add class modal
    function openAddClassModal() {
        addClassModal.classList.add('active');
    }
    
    //Open add student modal
    function openAddStudentModal() {
        // Populate class options in the student form
        populateClassOptions();
        addStudentModal.classList.add('active');
    }

    //Close all modals
    function closeAllModals() {
        addClassModal.classList.remove('active');
        addStudentModal.classList.remove('active');
    }
    
    // Add class
    function addClass() {
        const classId = document.getElementById('class-id').value;
        const className = document.getElementById('class-name').value;
        const classTeacher = document.getElementById('class-teacher').value;
        
        const newClass = {
            id: classId,
            name: className,
            teacher: classTeacher
        };
        
        classes.push(newClass);
        updateClassFilter();
        
        // Save to local storage
        saveData();
        
        // Export to GitHub
        exportToGithub();
        
        // Reset form
        addClassForm.reset();
        closeAllModals();
    }

    // Add student
    function addStudent() {
        const lastName = document.getElementById('student-last-name').value;
        const firstName = document.getElementById('student-first-name').value;
        const studentClass = document.getElementById('student-class').value;
        const birthDate = document.getElementById('student-birth-date').value;
        const email = document.getElementById('student-email').value;
        const phone = document.getElementById('student-phone').value;
        const photoUrl = document.getElementById('student-photo-url').value;
        
        const newStudent = {
            id: Math.random().toString(36).substring(2, 15), // Generate a random ID
            lastName: lastName,
            firstName: firstName,
            class: studentClass,
            birthDate: birthDate,
            email: email,
            phone: phone,
            photoUrl: photoUrl
        };
        
        students.push(newStudent);
        
        // Save to local storage
        saveData();
        
        // Reset form
        addStudentForm.reset();
        closeAllModals();
        renderStudents();
    }

    // Save all data to local storage
    function saveData() {
        localStorage.setItem('classes_data', JSON.stringify(classes));
        localStorage.setItem('students_data', JSON.stringify(students));
        
        // Update the class filter dropdown
        updateClassFilter();
        
        // Update the student list
        renderStudents();
        
        // Export to GitHub
        exportToGithub();
    }
    
    // Load data from local storage
    function loadData() {
        classes = JSON.parse(localStorage.getItem('classes_data') || '[]');
        students = JSON.parse(localStorage.getItem('students_data') || '[]');
    }

    // Update class filter options
    function updateClassFilter() {
        // Load classes
        loadData();
        
        // Clear existing options
        while (classFilter.options.length > 1) {
            classFilter.remove(1);
        }
        
        // Add new classes
        classes.forEach(cls => {
            const option = document.createElement('option');
            option.value = cls.id;
            option.textContent = cls.name;
            classFilter.add(option);
        });
        
        // Populate the student class select
        populateClassOptions();

        //save to evaluation data filter class
        localStorage.setItem('classes_data_eval', JSON.stringify(classes));
    }
    
    // Populate the student class select
    function populateClassOptions() {
        // Clear existing options
        while (studentClassSelect.options.length > 1) {
            studentClassSelect.remove(1);
        }
        
        // Add new classes
         classes.forEach(cls => {
            const option = document.createElement('option');
            option.value = cls.id;
            option.textContent = cls.name;
            studentClassSelect.add(option);
        });
    }
    

    // Filter students based on current filter and search
    function getFilteredStudents() {
        return students.filter(student => {
            // Apply class filter
            if (currentFilter !== 'all' && student.class !== currentFilter) {
                return false;
            }
            
            // Apply search
            if (currentSearch) {
                const fullName = `${student.firstName} ${student.lastName}`.toLowerCase();
                return fullName.includes(currentSearch);
            }
            
            return true;
        });
    }

    // Get students for current page
    function getPaginatedStudents() {
        const filteredStudents = getFilteredStudents();
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        
        return filteredStudents.slice(start, end);
    }

    // Update pagination controls
    function updatePagination() {
        const filteredStudents = getFilteredStudents();
        const totalPages = Math.ceil(filteredStudents.length / itemsPerPage);
        
        pageInfo.textContent = `Page ${currentPage} sur ${totalPages || 1}`;
        
        prevPageBtn.disabled = currentPage <= 1;
        nextPageBtn.disabled = currentPage >= totalPages;
    }

    // Render students in the current view
    function renderStudents() {
        // Load data to make sure we have the latest
        loadData();
        
        const paginatedStudents = getPaginatedStudents();
        
        // Clear current content
        studentsList.innerHTML = '';
        studentsGrid.innerHTML = '';
        
        // List view
        if (currentView === 'list') {
            paginatedStudents.forEach(student => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${student.lastName}</td>
                    <td>${student.firstName}</td>
                    <td>${student.class}</td>
                    <td>${student.birthDate}</td>
                    <td>${student.email}</td>
                    <td>${student.phone}</td>
                    <td class="actions-cell">
                        <button class="action-btn view" title="Voir"><i class="fas fa-eye"></i></button>
                        <button class="action-btn edit" title="Modifier"><i class="fas fa-edit"></i></button>
                        <button class="action-btn delete" title="Supprimer"><i class="fas fa-trash-alt"></i></button>
                    </td>
                `;
                
                // Setup row action buttons
                setupRowActions(row, student);
                
                studentsList.appendChild(row);
            });
        } 
        // Grid view (Trombinoscope)
        else if (currentView === 'grid') {
            paginatedStudents.forEach(student => {
                const card = document.createElement('div');
                card.className = 'student-card';
                
                const photoContent = student.photoUrl 
                    ? `<img src="${student.photoUrl}" alt="Photo de ${student.firstName} ${student.lastName}">`
                    : `<i class="fas fa-user"></i>`;
                
                card.innerHTML = `
                    <div class="student-photo">
                        ${photoContent}
                    </div>
                    <div class="student-info">
                        <h3 class="student-name">${student.firstName} ${student.lastName}</h3>
                        <p class="student-class">${student.class}</p>
                        <div class="student-details">
                            <p>${student.birthDate}</p>
                            <p>${student.email}</p>
                        </div>
                    </div>
                    <div class="student-actions">
                        <button class="action-btn view" title="Voir"><i class="fas fa-eye"></i></button>
                        <button class="action-btn edit" title="Modifier"><i class="fas fa-edit"></i></button>
                        <button class="action-btn delete" title="Supprimer"><i class="fas fa-trash-alt"></i></button>
                    </div>
                `;
                
                // Setup card action buttons
                setupCardActions(card, student);
                
                studentsGrid.appendChild(card);
            });
        }
        
        // Update pagination
        updatePagination();
    }

    // Setup action buttons for a row
    function setupRowActions(row, student) {
        const viewBtn = row.querySelector('.action-btn.view');
        const editBtn = row.querySelector('.action-btn.edit');
        const deleteBtn = row.querySelector('.action-btn.delete');
        
        viewBtn.addEventListener('click', () => viewStudent(student));
        editBtn.addEventListener('click', () => editStudent(student));
        deleteBtn.addEventListener('click', () => {
            if (deleteStudent(student)) {
                renderStudents(); // Refresh the view after successful deletion
            }
        });
    }

    // Setup action buttons for a card
    function setupCardActions(card, student) {
        const viewBtn = card.querySelector('.action-btn.view');
        const editBtn = card.querySelector('.action-btn.edit');
        const deleteBtn = card.querySelector('.action-btn.delete');
        
        viewBtn.addEventListener('click', () => viewStudent(student));
        editBtn.addEventListener('click', () => editStudent(student));
        deleteBtn.addEventListener('click', () => {
            if (deleteStudent(student)) {
                renderStudents(); // Refresh the view after successful deletion
            }
        });
    }

    // View student details
    function viewStudent(student) {
        // In a real application, this would open a modal or navigate to a student details page
        alert(`
            Détails de l'élève:
            Nom: ${student.lastName}
            Prénom: ${student.firstName}
            Classe: ${student.class}
            Date de naissance: ${student.birthDate}
            Email: ${student.email}
            Téléphone: ${student.phone}
        `);
    }

    // Edit student
    function editStudent(student) {
        // In a real application, this would open a modal or navigate to an edit form
        alert(`Modification de l'élève: ${student.firstName} ${student.lastName}`);
    }

    // Delete student
    function deleteStudent(student) {
        // In a real application, this would show a confirmation dialog and then delete
        const confirmed = confirm(`Voulez-vous vraiment supprimer l'élève ${student.firstName} ${student.lastName} ?`);
        
        if (confirmed) {
            // Remove student from the array
            students = students.filter(s => s.id !== student.id);
            
            // Save to local storage
            saveData();
            
            // Signal successful deletion
            return true;
        }
        return false;
    }

    // Export data to GitHub
    async function exportToGithub() {
        try {
            // Import the functions from gists-sync.js
            const module = await import('./gists-sync.js').catch(e => {
                console.error('Error importing gists-sync.js:', e);
                return null;
            });
            
            if (!module) return;
            
            const { saveToGist } = module;
            
            // Collect all data
            const dataToUpload = {
                userData: JSON.parse(localStorage.getItem('user_data') || '{}'),
                schedules: JSON.parse(localStorage.getItem('imported_calendars') || '[]'),
                classes: classes,
                evaluations: JSON.parse(localStorage.getItem('evaluations_data') || '[]'),
                students: JSON.parse(localStorage.getItem('students_data') || '[]'),
                grades: JSON.parse(localStorage.getItem('grades_data') || '{}')
            };
            
            // Save to GitHub
            await saveToGist(dataToUpload);
            
            // Update last sync date
            localStorage.setItem('last_sync_date', new Date().toISOString());
            
            console.log('Class data exported to GitHub Gists successfully');
        } catch (error) {
            console.error('Error exporting class data to GitHub:', error);
        }
    }

    // Load initial data
    loadData();

    // Update the class filter dropdown
    updateClassFilter();

    // Initialize the page
    init();
});