import { fetchFromGist, saveToGist, testGistConnection } from './gists-sync.js';

document.addEventListener('DOMContentLoaded', function() {
    // Clear all existing data for a fresh start
    localStorage.clear();
    localStorage.setItem('classes_data', JSON.stringify([]));
    localStorage.setItem('evaluations_data', JSON.stringify([]));
    localStorage.setItem('imported_calendars', JSON.stringify([]));
    localStorage.setItem('user_data', JSON.stringify({}));
    localStorage.setItem('students_data', JSON.stringify([]));
    localStorage.setItem('grades_data', JSON.stringify({}));
    localStorage.setItem('groups_data', JSON.stringify([]));
    localStorage.setItem('referentials_data', JSON.stringify([]));
    localStorage.setItem('competences_data', JSON.stringify([]));
    localStorage.setItem('comp_evaluations_data', JSON.stringify([]));
    localStorage.setItem('comp_assessments_data', JSON.stringify({}));

    // DOM Elements
    const btnImportData = document.getElementById('btn-import-data');
    const btnExportData = document.getElementById('btn-export-data');
    const btnBackupData = document.getElementById('btn-backup-data');
    const btnCleanData = document.getElementById('btn-clean-data');
    const btnResetData = document.getElementById('btn-reset-data');
    const btnSyncGithub = document.getElementById('btn-sync-github');
    const importModal = document.getElementById('import-modal');
    const exportModal = document.getElementById('export-modal');
    const confirmModal = document.getElementById('confirm-modal');
    const importForm = document.getElementById('import-form');
    const exportForm = document.getElementById('export-form');
    const importFile = document.getElementById('import-file');
    const importFileName = document.getElementById('import-file-name');
    const importPreview = document.getElementById('import-preview');
    const importPreviewContent = document.getElementById('import-preview-content');
    const importResult = document.getElementById('import-result');
    const closeButtons = document.querySelectorAll('.close-btn');
    const cancelImport = document.getElementById('cancel-import');
    const cancelExport = document.getElementById('cancel-export');
    const cancelConfirm = document.getElementById('cancel-confirm');
    const confirmAction = document.getElementById('confirm-action');
    const confirmMessage = document.getElementById('confirm-message');

    // Initialize
    updateDataStats();
    checkGistConnection().then(() => {
        // Auto-import data from GitHub on startup
        autoImportFromGithub();
    });
    
    // Check GitHub Gist connection
    async function checkGistConnection() {
        const syncStatus = document.getElementById('sync-status');
        const isConnected = await testGistConnection();
        
        if (isConnected) {
            syncStatus.textContent = 'Connecté';
            syncStatus.className = 'sync-status connected';
            btnSyncGithub.disabled = false;
        } else {
            syncStatus.textContent = 'Non connecté';
            syncStatus.className = 'sync-status disconnected';
            btnSyncGithub.disabled = true;
        }
        
        return isConnected;
    }
    
    // Auto-import data from GitHub on startup
    async function autoImportFromGithub() {
        try {
            // Check if auto-import has already been done
            const lastAutoImport = localStorage.getItem('last_auto_import_date');
            const currentDate = new Date().toDateString();
            
            console.log('Auto-importing data from GitHub...');
            
            // Fetch data from GitHub
            const githubData = await fetchFromGist();
            
            // Check if we have data to import
            if (!githubData || Object.keys(githubData).length === 0) {
                console.log('No data found on GitHub or empty data. Skipping auto-import.');
                return;
            }
            
            // If classes data exists, save it to localStorage
            if (githubData.classes) {
                localStorage.setItem('classes_data', JSON.stringify(githubData.classes));
                console.log('Classes data imported:', githubData.classes);
            }
            
            // Save each section to localStorage, replacing existing data
            if (githubData.userData) {
                localStorage.setItem('user_data', JSON.stringify(githubData.userData));
            }
            
            if (githubData.schedules) {
                localStorage.setItem('imported_calendars', JSON.stringify(githubData.schedules));
            }
            
            if (githubData.evaluations) {
                localStorage.setItem('evaluations_data', JSON.stringify(githubData.evaluations));
            }
            
            if (githubData.students) {
                localStorage.setItem('students_data', JSON.stringify(githubData.students));
            }
            
            if (githubData.grades) {
                localStorage.setItem('grades_data', JSON.stringify(githubData.grades));
            }
            
            if (githubData.groups) {
                localStorage.setItem('groups_data', JSON.stringify(githubData.groups));
            }
            
            if (githubData.referentials) {
                localStorage.setItem('referentials_data', JSON.stringify(githubData.referentials));
            }
            
            if (githubData.competences) {
                localStorage.setItem('competences_data', JSON.stringify(githubData.competences));
            }
            
            // Import comp evaluations data
            if (githubData.compEvaluations) {
                localStorage.setItem('comp_evaluations_data', JSON.stringify(githubData.compEvaluations));
            }
            
            // Import comp assessments data
            if (githubData.compAssessments) {
                localStorage.setItem('comp_assessments_data', JSON.stringify(githubData.compAssessments));
            }
            
            // Record that we did the auto-import today
            localStorage.setItem('last_auto_import_date', currentDate);
            localStorage.setItem('last_sync_date', new Date().toISOString());
            
            // Update data stats
            updateDataStats();
            
            console.log('Auto-import from GitHub completed successfully.');
            
        } catch (error) {
            console.error('Error during auto-import from GitHub:', error);
        }
    }
    
    // Setup event listeners
    function setupEventListeners() {
        // Open import modal
        btnImportData.addEventListener('click', function() {
            openModal(importModal);
            resetForm(importForm);
            importPreview.style.display = 'none';
            importResult.style.display = 'none';
        });
        
        // Open export modal
        btnExportData.addEventListener('click', function() {
            openModal(exportModal);
            resetForm(exportForm);
        });
        
        // Handle file selection
        importFile.addEventListener('change', function() {
            handleFileSelect(this);
        });
        
        // Handle form submissions
        importForm.addEventListener('submit', function(e) {
            e.preventDefault();
            importData();
        });
        
        exportForm.addEventListener('submit', function(e) {
            e.preventDefault();
            exportData();
        });
        
        // Close modals
        closeButtons.forEach(button => {
            button.addEventListener('click', closeAllModals);
        });
        
        // Cancel buttons
        cancelImport.addEventListener('click', closeAllModals);
        cancelExport.addEventListener('click', closeAllModals);
        cancelConfirm.addEventListener('click', closeAllModals);
        
        // Other action buttons
        btnBackupData.addEventListener('click', backupData);
        btnCleanData.addEventListener('click', promptCleanData);
        btnResetData.addEventListener('click', promptResetData);
        
        // GitHub sync button
        btnSyncGithub.addEventListener('click', promptSyncWithGithub);
    }
    
    // Open modal
    function openModal(modal) {
        modal.classList.add('active');
    }
    
    // Close all modals
    function closeAllModals() {
        importModal.classList.remove('active');
        exportModal.classList.remove('active');
        confirmModal.classList.remove('active');
    }
    
    // Reset form
    function resetForm(form) {
        form.reset();
        importFileName.textContent = 'Aucun fichier sélectionné';
    }
    
    // Handle file selection
    function handleFileSelect(fileInput) {
        if (fileInput.files && fileInput.files[0]) {
            const file = fileInput.files[0];
            importFileName.textContent = file.name;
            
            // Read file and show preview
            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const data = JSON.parse(e.target.result);
                    // Show a preview (simplified version)
                    const preview = {
                        userData: data.userData ? '✓' : '✗',
                        schedules: data.schedules ? `${data.schedules.length} calendriers` : '✗',
                        classes: data.classes ? `${data.classes.length} classes` : '✗',
                        evaluations: data.evaluations ? `${data.evaluations.length} évaluations` : '✗',
                    };
                    
                    importPreviewContent.textContent = JSON.stringify(preview, null, 2);
                    importPreview.style.display = 'block';
                } catch (error) {
                    showImportError('Le fichier JSON est invalide ou mal formaté.');
                }
            };
            
            reader.readAsText(file);
        }
    }
    
    // Import data
    function importData() {
        const file = importFile.files[0];
        if (!file) {
            showImportError('Veuillez sélectionner un fichier JSON.');
            return;
        }
        
        const mergeData = document.getElementById('import-merge').checked;
        const importUserData = document.getElementById('import-user-data').checked;
        const importSchedules = document.getElementById('import-schedules').checked;
        const importClasses = document.getElementById('import-classes').checked;
        const importStudents = document.getElementById('import-students').checked;
        const importGroups = document.getElementById('import-groups').checked;
        const importEvaluations = document.getElementById('import-evaluations').checked;
        const importGrades = document.getElementById('import-grades').checked;
        const importReferentials = document.getElementById('import-referentials').checked;
        const importCompetences = document.getElementById('import-competences').checked;
        const importCompEvaluations = document.getElementById('import-comp-evaluations').checked;
        
        const reader = new FileReader();
        reader.onload = function(e) {
            try {
                // Parse the JSON data
                const importedData = JSON.parse(e.target.result);
                
                // Validate the structure
                if (!validateDataStructure(importedData)) {
                    showImportError('Le format des données est invalide.');
                    return;
                }
                
                // Store data based on selected options
                if (importUserData && importedData.userData) {
                    saveUserData(importedData.userData, mergeData);
                }
                
                if (importSchedules && importedData.schedules) {
                    saveSchedulesData(importedData.schedules, mergeData);
                }
                
                if (importClasses && importedData.classes) {
                    saveClassesData(importedData.classes, mergeData);
                }
                
                if (importStudents && importedData.students) {
                    saveStudentsData(importedData.students, mergeData);
                }
                
                if (importGroups && importedData.groups) {
                    saveGroupsData(importedData.groups, mergeData);
                }
                
                if (importEvaluations && importedData.evaluations) {
                    saveEvaluationsData(importedData.evaluations, mergeData);
                }
                
                if (importGrades && importedData.grades) {
                    saveGradesData(importedData.grades, mergeData);
                }
                
                if (importReferentials && importedData.referentials) {
                    saveReferentialsData(importedData.referentials, mergeData);
                }
                
                if (importCompetences && importedData.competences) {
                    saveCompetencesData(importedData.competences, mergeData);
                }
                
                // Import comp evaluations data
                if (importCompEvaluations && importedData.compEvaluations) {
                    localStorage.setItem('comp_evaluations_data', JSON.stringify(importedData.compEvaluations));
                
                    // Import comp assessments data if importing comp evaluations
                    if (importedData.compAssessments) {
                        localStorage.setItem('comp_assessments_data', JSON.stringify(importedData.compAssessments));
                    }
                }
                
                // Show success message
                showImportSuccess('Les données ont été importées avec succès !');
                
                // Update stats
                updateDataStats();
                
                // Close modal after a delay
                setTimeout(closeAllModals, 2000);
                
            } catch (error) {
                showImportError('Erreur lors de l\'importation: ' + error.message);
            }
        };
        
        reader.readAsText(file);
    }
    
    // Export data
    function exportData() {
        // Get options
        const exportUserData = document.getElementById('export-user-data').checked;
        const exportSchedules = document.getElementById('export-schedules').checked;
        const exportClasses = document.getElementById('export-classes').checked;
        const exportStudents = document.getElementById('export-students').checked;
        const exportGroups = document.getElementById('export-groups').checked;
        const exportEvaluations = document.getElementById('export-evaluations').checked;
        const exportGrades = document.getElementById('export-grades').checked;
        const exportReferentials = document.getElementById('export-referentials').checked;
        const exportCompetences = document.getElementById('export-competences').checked;
        const exportCompEvaluations = document.getElementById('export-comp-evaluations').checked;
        const filename = document.getElementById('export-filename').value || 'logisuiel_data_export';
        
        // Create the export object
        const exportObject = {};
        
        // Add data based on selected options
        if (exportUserData) {
            exportObject.userData = getUserData();
        }
        
        if (exportSchedules) {
            exportObject.schedules = getSchedulesData();
        }
        
        if (exportClasses) {
            exportObject.classes = getClassesData();
        }
        
        if (exportStudents) {
            exportObject.students = getStudentsData();
        }
        
        if (exportGroups) {
            exportObject.groups = getGroupsData();
        }
        
        if (exportEvaluations) {
            exportObject.evaluations = getEvaluationsData();
        }
        
        if (exportGrades) {
            exportObject.grades = getGradesData();
        }
        
        if (exportReferentials) {
            exportObject.referentials = getReferentialsData();
        }
        
        if (exportCompetences) {
            exportObject.competences = getCompetencesData();
        }
        
        if (exportCompEvaluations) {
            const compEvaluations = JSON.parse(localStorage.getItem('comp_evaluations_data') || '[]');
            exportObject.compEvaluations = compEvaluations;
            
            // Add comp assessments data if exporting comp evaluations
            const compAssessments = JSON.parse(localStorage.getItem('comp_assessments_data') || '{}');
            exportObject.compAssessments = compAssessments;
        }
        
        // Generate JSON and download
        const jsonData = JSON.stringify(exportObject, null, 2);
        downloadJson(jsonData, `${filename}.json`);
        
        // Close modal
        closeAllModals();
    }
    
    // Validate imported data structure
    function validateDataStructure(data) {
        // Basic validation - check if the structure matches our expectations
        // In a real app, this would be more thorough
        if (typeof data !== 'object') return false;
        
        // Check specific sections
        if (data.userData && typeof data.userData !== 'object') return false;
        if (data.schedules && !Array.isArray(data.schedules)) return false;
        if (data.classes && !Array.isArray(data.classes)) return false;
        if (data.evaluations && !Array.isArray(data.evaluations)) return false;
        if (data.students && !Array.isArray(data.students)) return false;
        if (data.grades && typeof data.grades !== 'object') return false;
        if (data.groups && !Array.isArray(data.groups)) return false;
        if (data.referentials && !Array.isArray(data.referentials)) return false;
        if (data.competences && !Array.isArray(data.competences)) return false;
        
        return true;
    }
    
    // Save user data
    function saveUserData(userData, merge) {
        if (merge) {
            // Merge with existing data
            const existingData = getUserData();
            localStorage.setItem('user_data', JSON.stringify({ 
                ...existingData, 
                ...userData 
            }));
        } else {
            // Replace existing data
            localStorage.setItem('user_data', JSON.stringify(userData));
        }
    }
    
    // Save schedules data
    function saveSchedulesData(schedules, merge) {
        if (merge) {
            // Merge with existing calendars
            const existingCalendars = JSON.parse(localStorage.getItem('imported_calendars') || '[]');
            
            // Use a Map to deduplicate by name
            const calendarsMap = new Map();
            existingCalendars.forEach(cal => calendarsMap.set(cal.name, cal));
            schedules.forEach(cal => calendarsMap.set(cal.name, cal));
            
            // Convert back to array
            const mergedCalendars = Array.from(calendarsMap.values());
            localStorage.setItem('imported_calendars', JSON.stringify(mergedCalendars));
        } else {
            // Replace existing calendars
            localStorage.setItem('imported_calendars', JSON.stringify(schedules));
        }
    }
    
    // Save classes data
    function saveClassesData(classes, merge) {
        // In a real app, this would handle the classes and students data
        localStorage.setItem('classes_data', JSON.stringify(classes));
    }
    
    function saveStudentsData(students, merge) {
        localStorage.setItem('students_data', JSON.stringify(students));
    }
    
    // Save evaluations data
    function saveEvaluationsData(evaluations, merge) {
        // In a real app, this would handle the evaluations and grades data
        localStorage.setItem('evaluations_data', JSON.stringify(evaluations));
    }
    
    // Save grades data
    function saveGradesData(grades, merge) {
        if (merge) {
            const existingGrades = JSON.parse(localStorage.getItem('grades_data') || '{}');
            const mergedGrades = { ...existingGrades, ...grades };
            localStorage.setItem('grades_data', JSON.stringify(mergedGrades));
        } else {
            localStorage.setItem('grades_data', JSON.stringify(grades));
        }
    }
    
    function saveGroupsData(groups, merge) {
        if (merge) {
            const existingGroups = JSON.parse(localStorage.getItem('groups_data') || '[]');
            const mergedGroups = [...existingGroups, ...groups];
            localStorage.setItem('groups_data', JSON.stringify(mergedGroups));
        } else {
            localStorage.setItem('groups_data', JSON.stringify(groups));
        }
    }
    
    function saveReferentialsData(referentials, merge) {
        if (merge) {
            const existingReferentials = JSON.parse(localStorage.getItem('referentials_data') || '[]');
            const mergedReferentials = [...existingReferentials, ...referentials];
            localStorage.setItem('referentials_data', JSON.stringify(mergedReferentials));
        } else {
            localStorage.setItem('referentials_data', JSON.stringify(referentials));
        }
    }
    
    function saveCompetencesData(competences, merge) {
        if (merge) {
            const existingCompetences = JSON.parse(localStorage.getItem('competences_data') || '[]');
            const mergedCompetences = [...existingCompetences, ...competences];
            localStorage.setItem('competences_data', JSON.stringify(mergedCompetences));
        } else {
            localStorage.setItem('competences_data', JSON.stringify(competences));
        }
    }
    
    // Get user data
    function getUserData() {
        return JSON.parse(localStorage.getItem('user_data') || '{}');
    }
    
    // Get schedules data
    function getSchedulesData() {
        return JSON.parse(localStorage.getItem('imported_calendars') || '[]');
    }
    
    // Get classes data
    function getClassesData() {
        // Return empty array instead of sample data
        return JSON.parse(localStorage.getItem('classes_data') || '[]');
    }
    
    // Get evaluations data
    function getEvaluationsData() {
        // Return empty array instead of sample data
        return JSON.parse(localStorage.getItem('evaluations_data') || '[]');
    }
    
    // Get students data
    function getStudentsData() {
        return JSON.parse(localStorage.getItem('students_data') || '[]');
    }
    
    // Get grades data
    function getGradesData() {
        return JSON.parse(localStorage.getItem('grades_data') || '{}');
    }
    
    function getGroupsData() {
        return JSON.parse(localStorage.getItem('groups_data') || '[]');
    }
    
    function getReferentialsData() {
        return JSON.parse(localStorage.getItem('referentials_data') || '[]');
    }
    
    function getCompetencesData() {
        return JSON.parse(localStorage.getItem('competences_data') || '[]');
    }
    
    // Download JSON file
    function downloadJson(jsonData, filename) {
        const blob = new Blob([jsonData], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
    
    // Show import error
    function showImportError(message) {
        const alertBox = importResult.querySelector('.alert');
        alertBox.className = 'alert error';
        alertBox.textContent = message;
        importResult.style.display = 'block';
    }
    
    // Show import success
    function showImportSuccess(message) {
        const alertBox = importResult.querySelector('.alert');
        alertBox.className = 'alert success';
        alertBox.textContent = message;
        importResult.style.display = 'block';
    }
    
    // Prompt to sync with GitHub
    function promptSyncWithGithub() {
        confirmMessage.textContent = 'Souhaitez-vous synchroniser vos données avec GitHub Gists ? Vous pouvez soit télécharger les données depuis GitHub, soit envoyer vos données locales vers GitHub.';
        openModal(confirmModal);
        
        // Change confirm modal to have download and upload buttons
        const actionsContainer = confirmModal.querySelector('.form-actions');
        actionsContainer.innerHTML = `
            <button type="button" class="btn btn-secondary" id="cancel-sync">Annuler</button>
            <button type="button" class="btn btn-primary" id="download-from-github">Télécharger depuis GitHub</button>
            <button type="button" class="btn btn-primary" id="upload-to-github">Envoyer vers GitHub</button>
        `;
        
        // Setup action buttons
        document.getElementById('cancel-sync').addEventListener('click', closeAllModals);
        document.getElementById('download-from-github').addEventListener('click', downloadFromGithub);
        document.getElementById('upload-to-github').addEventListener('click', uploadToGithub);
    }
    
    // Download data from GitHub Gists
    async function downloadFromGithub() {
        try {
            // Show loading state
            confirmMessage.textContent = 'Téléchargement des données depuis GitHub...';
            const actionsContainer = confirmModal.querySelector('.form-actions');
            actionsContainer.style.display = 'none';
            
            // Fetch data from GitHub
            const githubData = await fetchFromGist();
            
            // Save each section to localStorage, replacing existing data
            if (githubData.userData) {
                localStorage.setItem('user_data', JSON.stringify(githubData.userData));
            }
            
            if (githubData.schedules) {
                localStorage.setItem('imported_calendars', JSON.stringify(githubData.schedules));
            }
            
            if (githubData.classes) {
                localStorage.setItem('classes_data', JSON.stringify(githubData.classes));
            }
            
            if (githubData.evaluations) {
                localStorage.setItem('evaluations_data', JSON.stringify(githubData.evaluations));
            }
            
            if (githubData.students) {
                localStorage.setItem('students_data', JSON.stringify(githubData.students));
            }
            
            if (githubData.grades) {
                localStorage.setItem('grades_data', JSON.stringify(githubData.grades));
            }
            
            if (githubData.groups) {
                localStorage.setItem('groups_data', JSON.stringify(githubData.groups));
            }
            
            if (githubData.referentials) {
                localStorage.setItem('referentials_data', JSON.stringify(githubData.referentials));
            }
            
            if (githubData.competences) {
                localStorage.setItem('competences_data', JSON.stringify(githubData.competences));
            }
            
            // Import comp evaluations data
            if (githubData.compEvaluations) {
                localStorage.setItem('comp_evaluations_data', JSON.stringify(githubData.compEvaluations));
            }
            
            // Import comp assessments data
            if (githubData.compAssessments) {
                localStorage.setItem('comp_assessments_data', JSON.stringify(githubData.compAssessments));
            }
            
            // Update data stats
            updateDataStats();
            
            // Show success message
            confirmMessage.textContent = 'Données téléchargées avec succès depuis GitHub !';
            actionsContainer.innerHTML = '<button type="button" class="btn btn-primary" id="close-sync">Fermer</button>';
            actionsContainer.style.display = 'flex';
            document.getElementById('close-sync').addEventListener('click', function() {
                closeAllModals();
                // Reload the page to display new data
                window.location.reload();
            });
            
        } catch (error) {
            // Show error message
            confirmMessage.textContent = `Erreur lors du téléchargement des données: ${error.message}`;
            const actionsContainer = confirmModal.querySelector('.form-actions');
            actionsContainer.innerHTML = '<button type="button" class="btn btn-primary" id="close-sync">Fermer</button>';
            actionsContainer.style.display = 'flex';
            document.getElementById('close-sync').addEventListener('click', closeAllModals);
        }
    }
    
    // Upload data to GitHub Gists
    async function uploadToGithub() {
        try {
            // Show loading state
            confirmMessage.textContent = 'Envoi des données vers GitHub...';
            const actionsContainer = confirmModal.querySelector('.form-actions');
            actionsContainer.style.display = 'none';
            
            // Prepare data object
            const dataToUpload = {
                userData: getUserData(),
                schedules: getSchedulesData(),
                classes: getClassesData(),
                evaluations: getEvaluationsData(),
                students: getStudentsData(),
                grades: getGradesData(),
                groups: getGroupsData(),
                referentials: getReferentialsData(),
                competences: getCompetencesData(),
                compEvaluations: JSON.parse(localStorage.getItem('comp_evaluations_data') || '[]'),
                compAssessments: JSON.parse(localStorage.getItem('comp_assessments_data') || '{}')
            };
            
            // Upload to GitHub
            await saveToGist(dataToUpload);
            
            // Show success message
            confirmMessage.textContent = 'Données envoyées avec succès vers GitHub !';
            actionsContainer.innerHTML = '<button type="button" class="btn btn-primary" id="close-sync">Fermer</button>';
            actionsContainer.style.display = 'flex';
            document.getElementById('close-sync').addEventListener('click', closeAllModals);
            
            // Update last save date
            localStorage.setItem('last_sync_date', new Date().toISOString());
            localStorage.setItem('last_save_date', new Date().toISOString());
            updateDataStats();
            
        } catch (error) {
            // Show error message
            confirmMessage.textContent = `Erreur lors de l'envoi des données: ${error.message}`;
            const actionsContainer = confirmModal.querySelector('.form-actions');
            actionsContainer.innerHTML = '<button type="button" class="btn btn-primary" id="close-sync">Fermer</button>';
            actionsContainer.style.display = 'flex';
            document.getElementById('close-sync').addEventListener('click', closeAllModals);
        }
    }
    
    // Update data statistics
    function updateDataStats() {
        // Calculate last save date
        const lastSave = localStorage.getItem('last_save_date');
        document.getElementById('last-save-date').textContent = lastSave ? new Date(lastSave).toLocaleString() : 'Jamais';
        
        // Count calendars
        const calendars = getSchedulesData();
        document.getElementById('calendars-count').textContent = calendars.length;
        
        // Calculate calendar events (slots)
        let calendarEventsCount = 0;
        calendars.forEach(calendar => {
            if (calendar.events && Array.isArray(calendar.events)) {
                calendarEventsCount += calendar.events.length;
            }
        });
        
        // Update calendar events count in the HTML
        const dataStats = document.querySelector('.data-stats');
        // Check if the calendar events stat already exists
        let calendarEventsItem = document.getElementById('calendar-events-count');
        if (!calendarEventsItem) {
            // Create new stat item if it doesn't exist
            const statItem = document.createElement('div');
            statItem.className = 'stat-item';
            statItem.innerHTML = `
                <div class="stat-value" id="calendar-events-count">${calendarEventsCount}</div>
                <div class="stat-label">Créneaux calendrier</div>
            `;
            dataStats.appendChild(statItem);
        } else {
            // Update existing stat item
            calendarEventsItem.textContent = calendarEventsCount;
        }
        
        // Update class count
        const classes = getClassesData();
        document.getElementById('classes-count').textContent = classes.length || '0';
        
        // Update student count
        const students = getStudentsData();
        document.getElementById('students-count').textContent = students.length || '0';
        
        // Update groups count
        const groups = getGroupsData();
        document.getElementById('groups-count').textContent = groups.length || '0';
        
        // Update evaluations count
        const evaluations = getEvaluationsData();
        document.getElementById('evaluations-count').textContent = evaluations.length || '0';
        
        // Count entered grades
        const gradesData = JSON.parse(localStorage.getItem('grades_data') || '{}');
        let gradesCount = 0;
        for (const evalId in gradesData) {
            gradesData[evalId].forEach(student => {
                if (student.grade !== null && !student.absent && !student.nonNoted) {
                    gradesCount++;
                }
            });
        }
        document.getElementById('grades-count').textContent = gradesCount;
        
        // Count referentials and competences
        const referentials = JSON.parse(localStorage.getItem('referentials_data') || '[]');
        const competences = JSON.parse(localStorage.getItem('competences_data') || '[]');
        
        // Create or update referentials count stat item
        let referentialsItem = document.getElementById('referentials-count');
        if (!referentialsItem) {
            const statItem = document.createElement('div');
            statItem.className = 'stat-item';
            statItem.innerHTML = `
                <div class="stat-value" id="referentials-count">${referentials.length}</div>
                <div class="stat-label">Référentiels</div>
            `;
            dataStats.appendChild(statItem);
        } else {
            referentialsItem.textContent = referentials.length;
        }
        
        // Create or update competences count stat item
        let competencesItem = document.getElementById('competences-count');
        if (!competencesItem) {
            const statItem = document.createElement('div');
            statItem.className = 'stat-item';
            statItem.innerHTML = `
                <div class="stat-value" id="competences-count">${competences.length}</div>
                <div class="stat-label">Compétences</div>
            `;
            dataStats.appendChild(statItem);
        } else {
            competencesItem.textContent = competences.length;
        }
        
        // Count competences evaluations
        const compEvaluations = JSON.parse(localStorage.getItem('comp_evaluations_data') || '[]');
        
        // Create or update comp evaluations count stat item
        let compEvalsItem = document.getElementById('comp-evaluations-count');
        if (!compEvalsItem) {
            const statItem = document.createElement('div');
            statItem.className = 'stat-item';
            statItem.innerHTML = `
                <div class="stat-value" id="comp-evaluations-count">${compEvaluations.length}</div>
                <div class="stat-label">Évaluations par compétences</div>
            `;
            dataStats.appendChild(statItem);
        } else {
            compEvalsItem.textContent = compEvaluations.length;
        }
        
        // Update data size estimate
        let totalSize = 0;
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            totalSize += localStorage.getItem(key).length;
        }
        
        // Convert to KB
        const sizeInKB = Math.round(totalSize / 1024);
        document.getElementById('data-size').textContent = `${sizeInKB} Ko`;
        
        // Update last sync date if available
        const lastSync = localStorage.getItem('last_sync_date');
        if (document.getElementById('last-sync-date')) {
            document.getElementById('last-sync-date').textContent = lastSync ? new Date(lastSync).toLocaleString() : 'Jamais';
        }
        
        // Store last save date if not already set
        if (!lastSave) {
            localStorage.setItem('last_save_date', new Date().toISOString());
        }
    }
    
    // Backup data
    function backupData() {
        // Create a full backup of all data
        const backup = {};
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            try {
                backup[key] = JSON.parse(localStorage.getItem(key));
            } catch (e) {
                backup[key] = localStorage.getItem(key);
            }
        }
        
        // Download the backup
        const jsonData = JSON.stringify(backup, null, 2);
        const now = new Date();
        const timestamp = `${now.getFullYear()}-${(now.getMonth() + 1).toString().padStart(2, '0')}-${now.getDate().toString().padStart(2, '0')}`;
        downloadJson(jsonData, `logisuiel_backup_${timestamp}.json`);
        
        // Update last save date
        localStorage.setItem('last_save_date', now.toISOString());
        updateDataStats();
    }
    
    // Prompt to clean data
    function promptCleanData() {
        confirmMessage.textContent = 'Êtes-vous sûr de vouloir nettoyer les données obsolètes ? Cette action est irréversible.';
        openModal(confirmModal);
        
        // Setup confirm action
        confirmAction.onclick = cleanData;
    }
    
    // Clean obsolete data
    function cleanData() {
        // In a real app, this would identify and remove old/unused data
        // For demo purposes, we'll just remove empty arrays and objects
        
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            try {
                const value = JSON.parse(localStorage.getItem(key));
                
                if (Array.isArray(value) && value.length === 0) {
                    localStorage.removeItem(key);
                    i--; // Adjust for the removed item
                } else if (typeof value === 'object' && value !== null && Object.keys(value).length === 0) {
                    localStorage.removeItem(key);
                    i--; // Adjust for the removed item
                }
            } catch (e) {
                // Not JSON data, skip
            }
        }
        
        // Update stats
        updateDataStats();
        closeAllModals();
        
        // Show temporary success message
        alert('Les données obsolètes ont été nettoyées avec succès !');
    }
    
    // Prompt to reset data
    function promptResetData() {
        confirmMessage.textContent = 'Êtes-vous sûr de vouloir réinitialiser toutes les données ? Cette action est irréversible et supprimera définitivement toutes vos données.';
        openModal(confirmModal);
        
        // Setup confirm action
        confirmAction.onclick = resetData;
    }
    
    // Reset all data
    function resetData() {
        // Clear all localStorage
        localStorage.clear();
        
        // Initialize with empty structures
        localStorage.setItem('imported_calendars', JSON.stringify([]));
        localStorage.setItem('classes_data', JSON.stringify([]));
        localStorage.setItem('evaluations_data', JSON.stringify([]));
        localStorage.setItem('user_data', JSON.stringify({}));
        localStorage.setItem('students_data', JSON.stringify([]));
        localStorage.setItem('grades_data', JSON.stringify({}));
        localStorage.setItem('groups_data', JSON.stringify([]));
        localStorage.setItem('referentials_data', JSON.stringify([]));
        localStorage.setItem('competences_data', JSON.stringify([]));
        localStorage.setItem('comp_evaluations_data', JSON.stringify([]));
        localStorage.setItem('comp_assessments_data', JSON.stringify({}));
        
        // Update stats
        updateDataStats();
        closeAllModals();
        
        // Show temporary success message
        alert('Toutes les données ont été réinitialisées avec succès !');
        
        // Reload page to reflect changes
        window.location.reload();
    }
    
    // Run setup
    setupEventListeners();
});