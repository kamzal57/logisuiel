document.addEventListener('DOMContentLoaded', function() {
    // Toggle submenu
    const submenuLinks = document.querySelectorAll('.has-submenu > a');
    submenuLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const parent = this.parentElement;
            
            // Close all other open submenus
            const openMenus = document.querySelectorAll('.has-submenu.active');
            openMenus.forEach(menu => {
                if (menu !== parent) {
                    menu.classList.remove('active');
                }
            });
            
            // Toggle the current submenu
            parent.classList.toggle('active');
            
            // Export data to GitHub after any button click
            exportAllDataToGithub();
        });
    });

    // Auto-expand menu items that are already marked as active in the current page
    const activeMenuItems = document.querySelectorAll('.has-submenu.active');
    activeMenuItems.forEach(item => {
        const submenu = item.querySelector('.submenu');
        if (submenu) {
            const currentPage = window.location.pathname.split('/').pop();
            const menuLinks = submenu.querySelectorAll('a');
            let shouldStayOpen = false;
            
            // Check if any submenu link points to the current page
            menuLinks.forEach(link => {
                if (link.getAttribute('href') === currentPage) {
                    shouldStayOpen = true;
                }
            });
            
            if (!shouldStayOpen) {
                item.classList.remove('active');
            }
        }
    });
    
    // Add global click event listener for all buttons
    document.addEventListener('click', function(e) {
        if (e.target.tagName === 'BUTTON' || e.target.closest('button')) {
            // Export data to GitHub after any button click
            exportAllDataToGithub();
        }
    });
});

// Function to export all data to GitHub
async function exportAllDataToGithub() {
    try {
        // Import the functions from gists-sync.js
        const module = await import('./gists-sync.js').catch(e => {
            console.error('Error importing gists-sync.js:', e);
            return null;
        });
        
        if (!module) return;
        
        const { saveToGist } = module;
        
        // Collect all data
        const dataToUpload = {
            userData: JSON.parse(localStorage.getItem('user_data') || '{}'),
            schedules: JSON.parse(localStorage.getItem('imported_calendars') || '[]'),
            classes: JSON.parse(localStorage.getItem('classes_data') || '[]'),
            evaluations: JSON.parse(localStorage.getItem('evaluations_data') || '[]'),
            students: JSON.parse(localStorage.getItem('students_data') || '[]'),
            grades: JSON.parse(localStorage.getItem('grades_data') || '{}'),
            groups: JSON.parse(localStorage.getItem('groups_data') || '[]'),
            referentials: JSON.parse(localStorage.getItem('referentials_data') || '[]'),
            competences: JSON.parse(localStorage.getItem('competences_data') || '[]'),
            compEvaluations: JSON.parse(localStorage.getItem('comp_evaluations_data') || '[]'),
            compAssessments: JSON.parse(localStorage.getItem('comp_assessments_data') || '{}')
        };
        
        // Save to GitHub
        await saveToGist(dataToUpload);
        
        // Update last sync date
        localStorage.setItem('last_sync_date', new Date().toISOString());
        
        console.log('All data exported to GitHub Gists successfully');
    } catch (error) {
        console.error('Error exporting data to GitHub:', error);
    }
}