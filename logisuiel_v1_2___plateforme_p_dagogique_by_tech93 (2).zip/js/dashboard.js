import 'chart.js';

document.addEventListener('DOMContentLoaded', function() {
    // Setup empty charts
    setupEmptyStudentStatsChart();
    
    // Setup date navigation with current date
    setupDateNavigation();
    
    // Set current date for dashboard
    setCurrentDate();
    
    // Load calendar events for dashboard agenda
    loadDashboardCalendarEvents();
});

// Setup student statistics chart with empty data
function setupEmptyStudentStatsChart() {
    const ctx = document.getElementById('student-stats-chart').getContext('2d');
    
    // Empty data - would be populated from user data in a real application
    const chartData = {
        labels: [],
        datasets: [
            {
                label: 'Moyenne de classe',
                data: [],
                backgroundColor: 'rgba(52, 152, 219, 0.6)',
                borderColor: 'rgba(52, 152, 219, 1)',
                borderWidth: 1
            },
            {
                label: 'Moyenne nationale',
                data: [],
                backgroundColor: 'rgba(46, 204, 113, 0.6)',
                borderColor: 'rgba(46, 204, 113, 1)',
                borderWidth: 1
            }
        ]
    };
    
    const chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: false,
                min: 8,
                max: 20
            }
        },
        plugins: {
            legend: {
                position: 'bottom'
            },
            title: {
                display: true,
                text: 'Aucune donnée disponible',
                padding: {
                    top: 10,
                    bottom: 20
                }
            }
        }
    };
    
    new Chart(ctx, {
        type: 'bar',
        data: chartData,
        options: chartOptions
    });
}

// Setup date navigation for agenda
function setupDateNavigation() {
    const prevDayBtn = document.querySelector('.date-header .btn-icon:first-child');
    const nextDayBtn = document.querySelector('.date-header .btn-icon:last-child');
    const dateHeader = document.querySelector('.date-header h4');
    
    // Sample dates for demonstration
    const dates = [
        'Lundi 17 juin 2024',
        'Mardi 18 juin 2024',
        'Mercredi 19 juin 2024',
        'Jeudi 20 juin 2024',
        'Vendredi 21 juin 2024'
    ];
    
    let currentDateIndex = 0;
    
    prevDayBtn.addEventListener('click', function() {
        if (currentDateIndex > 0) {
            currentDateIndex--;
            dateHeader.textContent = dates[currentDateIndex];
            updateSchedule(currentDateIndex);
        }
    });
    
    nextDayBtn.addEventListener('click', function() {
        if (currentDateIndex < dates.length - 1) {
            currentDateIndex++;
            dateHeader.textContent = dates[currentDateIndex];
            updateSchedule(currentDateIndex);
        }
    });
}

// Update schedule data based on selected date
function updateSchedule(dateIndex) {
    const scheduleList = document.querySelector('.schedule-list');
    
    // Empty schedule data - would be fetched from the server in a real application
    const scheduleData = [
        // Day 1
        [],
        // Day 2
        [],
        // Day 3
        [],
        // Day 4
        [],
        // Day 5
        ]
    
    // Clear current schedule
    scheduleList.innerHTML = '<div class="text-center">Aucun cours planifié</div>';
}

// Set current date in the dashboard
function setCurrentDate() {
    const now = new Date();
    const dayNames = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
    const monthNames = ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'];
    
    const dayName = dayNames[now.getDay()];
    const day = now.getDate();
    const month = monthNames[now.getMonth()];
    const year = now.getFullYear();
    
    const formattedDate = `${dayName} ${day} ${month} ${year}`;
    document.querySelector('.date-header h4').textContent = formattedDate;
    
    // Update the schedule for today
    updateSchedule(0);
}

// Load calendar events for dashboard agenda
function loadDashboardCalendarEvents() {
    // Get the schedule list container
    const scheduleList = document.querySelector('.schedule-list');
    
    // Get all imported calendars
    const calendars = JSON.parse(localStorage.getItem('imported_calendars') || '[]');
    
    // If no calendars found, leave the empty message
    if (calendars.length === 0 || !Array.isArray(calendars)) return;
    
    // Get today's date
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0]; // YYYY-MM-DD format
    
    // Collect all of today's events
    let todaysEvents = [];
    
    calendars.forEach(calendar => {
        if (!calendar.events || !Array.isArray(calendar.events)) return;
        
        calendar.events.forEach(event => {
            try {
                // Make sure we can handle both string dates and Date objects
                const startDate = event.start instanceof Date ? event.start : new Date(event.start);
                const endDate = event.end instanceof Date ? event.end : new Date(event.end);
                
                if (isNaN(startDate.getTime()) || isNaN(endDate.getTime())) return;
                
                // Fix: Convert date to local string to avoid issues with toISOString
                const eventDate = startDate.toLocaleDateString('fr-FR');
                const todayLocal = today.toLocaleDateString('fr-FR');
                
                // Only show events for today
                if (eventDate === todayLocal) {
                    todaysEvents.push({
                        title: event.title || 'Sans titre',
                        location: event.location || 'Aucun lieu',
                        start: startDate,
                        end: endDate,
                        color: calendar.color || '#3498db',
                        class: event.class || calendar.name || 'Cours'
                    });
                }
            } catch (error) {
                console.error('Error processing event:', error, event);
                // Skip this event if there's an error
            }
        });
    });
    // If no events today, leave the empty message
    if (todaysEvents.length === 0) return;
    
    // Sort events by start time
    todaysEvents.sort((a, b) => a.start - b.start);
    
    // Clear the list
    scheduleList.innerHTML = '';
    
    // Add each event to the list
    todaysEvents.forEach(event => {
        const hours = event.start.getHours().toString().padStart(2, '0');
        const minutes = event.start.getMinutes().toString().padStart(2, '0');
        const endHours = event.end.getHours().toString().padStart(2, '0');
        const endMinutes = event.end.getMinutes().toString().padStart(2, '0');
        
        // Determine subject class for styling
        let subjectClass = '';
        if (event.title.toLowerCase().includes('math')) subjectClass = 'math';
        else if (event.title.toLowerCase().includes('physique')) subjectClass = 'physics';
        else if (event.title.toLowerCase().includes('français')) subjectClass = 'french';
        
        const eventItem = document.createElement('div');
        eventItem.className = `schedule-item ${subjectClass || ''}`;
        eventItem.innerHTML = `
            <div class="time">${hours}:${minutes} - ${endHours}:${endMinutes}</div>
            <div class="schedule-details">
                <div class="subject ${subjectClass || ''}" style="color: ${event.color}">${event.title}</div>
                <div class="location">${event.location}</div>
                <div class="class">${event.class}</div>
            </div>
        `;
        
        scheduleList.appendChild(eventItem);
    });
}

// Function to personalize dashboard (placeholder)
function personalizeDashboard() {
    console.log('Personalizing dashboard...');
    // In a real application, this would save user preferences to the server
}

// Add event listener for the personalize button
document.querySelector('.section-controls .btn-primary').addEventListener('click', personalizeDashboard);