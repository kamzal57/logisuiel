document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const classesList = document.getElementById('classes-list');
    const groupsList = document.getElementById('groups-list');
    const btnAddClass = document.getElementById('btn-add-class');
    const btnAddGroup = document.getElementById('btn-add-group');
    const addClassModal = document.getElementById('add-class-modal');
    const addGroupModal = document.getElementById('add-group-modal');
    const editGroupModal = document.getElementById('edit-group-modal');
    const addClassForm = document.getElementById('add-class-form');
    const addGroupForm = document.getElementById('add-group-form');
    const editGroupForm = document.getElementById('edit-group-form');
    const closeButtons = document.querySelectorAll('.close-btn');
    const cancelAddClass = document.getElementById('cancel-add-class');
    const cancelAddGroup = document.getElementById('cancel-add-group');
    const cancelEditGroup = document.getElementById('cancel-edit-group');
    const groupClassSelect = document.getElementById('group-class');
    const editGroupClassSelect = document.getElementById('edit-group-class');
    const availableStudentsList = document.getElementById('available-students-list');
    const selectedStudentsList = document.getElementById('selected-students-list');
    const editAvailableStudentsList = document.getElementById('edit-available-students-list');
    const editSelectedStudentsList = document.getElementById('edit-selected-students-list');
    const addStudentBtn = document.getElementById('add-student');
    const removeStudentBtn = document.getElementById('remove-student');
    const editAddStudentBtn = document.getElementById('edit-add-student');
    const editRemoveStudentBtn = document.getElementById('edit-remove-student');
    const searchStudents = document.getElementById('search-students');
    const editSearchStudents = document.getElementById('edit-search-students');

    // State
    let classes = [];
    let students = [];
    let groups = [];
    let selectedAvailableStudents = [];
    let selectedGroupStudents = [];
    let currentEditGroupId = null;

    // Initialize
    init();

    function init() {
        loadData();
        renderClasses();
        renderGroups();
        setupEventListeners();
    }

    function setupEventListeners() {
        // Tab navigation
        tabButtons.forEach(button => {
            button.addEventListener('click', function() {
                const tabName = this.getAttribute('data-tab');
                
                // Remove active class from all buttons and tabs
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                // Add active class to current button and tab
                this.classList.add('active');
                document.getElementById(`${tabName}-tab`).classList.add('active');
                
                // Refresh the appropriate view
                if (tabName === 'classes') {
                    renderClasses();
                } else if (tabName === 'groups') {
                    renderGroups();
                }
            });
        });

        // Open modals
        btnAddClass.addEventListener('click', function() {
            openAddClassModal();
        });
        
        btnAddGroup.addEventListener('click', function() {
            openAddGroupModal();
        });
        
        // Close modals
        closeButtons.forEach(button => {
            button.addEventListener('click', function() {
                closeAllModals();
            });
        });
        
        cancelAddClass.addEventListener('click', function() {
            closeAllModals();
        });
        
        cancelAddGroup.addEventListener('click', function() {
            closeAllModals();
        });
        
        cancelEditGroup.addEventListener('click', function() {
            closeAllModals();
        });
        
        // Form submissions
        addClassForm.addEventListener('submit', function(e) {
            e.preventDefault();
            addClass();
        });
        
        addGroupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            addGroup();
        });
        
        editGroupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            updateGroup();
        });
        
        // Student selection (available students)
        availableStudentsList.addEventListener('click', function(e) {
            if (e.target.tagName === 'LI') {
                toggleStudentSelection(e.target, 'available');
            }
        });
        
        // Student selection (group students)
        selectedStudentsList.addEventListener('click', function(e) {
            if (e.target.tagName === 'LI') {
                toggleStudentSelection(e.target, 'group');
            }
        });
        
        // Edit mode student selection
        editAvailableStudentsList.addEventListener('click', function(e) {
            if (e.target.tagName === 'LI') {
                toggleStudentSelection(e.target, 'edit-available');
            }
        });
        
        editSelectedStudentsList.addEventListener('click', function(e) {
            if (e.target.tagName === 'LI') {
                toggleStudentSelection(e.target, 'edit-group');
            }
        });
        
        // Transfer buttons
        addStudentBtn.addEventListener('click', function() {
            transferStudents('add');
        });
        
        removeStudentBtn.addEventListener('click', function() {
            transferStudents('remove');
        });
        
        editAddStudentBtn.addEventListener('click', function() {
            transferStudents('edit-add');
        });
        
        editRemoveStudentBtn.addEventListener('click', function() {
            transferStudents('edit-remove');
        });
        
        // Search students
        searchStudents.addEventListener('input', function() {
            filterStudents(this.value, 'create');
        });
        
        editSearchStudents.addEventListener('input', function() {
            filterStudents(this.value, 'edit');
        });
        
        // Class selection changes
        groupClassSelect.addEventListener('change', function() {
            loadAvailableStudents(this.value);
        });
        
        editGroupClassSelect.addEventListener('change', function() {
            loadEditAvailableStudents(this.value);
        });
    }
    
    // Load data from localStorage
    function loadData() {
        classes = JSON.parse(localStorage.getItem('classes_data') || '[]');
        students = JSON.parse(localStorage.getItem('students_data') || '[]');
        groups = JSON.parse(localStorage.getItem('groups_data') || '[]');
    }
    
    // Save data to localStorage
    function saveData() {
        localStorage.setItem('classes_data', JSON.stringify(classes));
        localStorage.setItem('students_data', JSON.stringify(students));
        localStorage.setItem('groups_data', JSON.stringify(groups));
        
        // Export to GitHub
        exportToGithub();
    }
    
    // Render classes list
    function renderClasses() {
        classesList.innerHTML = '';
        
        if (classes.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="5" class="text-center">Aucune classe n\'a été créée</td>';
            classesList.appendChild(row);
            return;
        }
        
        classes.forEach(cls => {
            // Count students in this class
            const studentCount = students.filter(student => student.class === cls.id).length;
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${cls.id}</td>
                <td>${cls.name}</td>
                <td>${cls.teacher || '-'}</td>
                <td>${studentCount}</td>
                <td class="actions-cell">
                    <button class="action-btn students" title="Voir les élèves" data-id="${cls.id}">
                        <i class="fas fa-user-graduate"></i>
                    </button>
                    <button class="action-btn edit" title="Modifier" data-id="${cls.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete" title="Supprimer" data-id="${cls.id}">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </td>
            `;
            
            // Add event listeners for action buttons
            const studentsBtn = row.querySelector('.action-btn.students');
            const editBtn = row.querySelector('.action-btn.edit');
            const deleteBtn = row.querySelector('.action-btn.delete');
            
            studentsBtn.addEventListener('click', () => viewClassStudents(cls.id));
            editBtn.addEventListener('click', () => editClass(cls.id));
            deleteBtn.addEventListener('click', () => confirmDeleteClass(cls.id));
            
            classesList.appendChild(row);
        });
    }
    
    // Render groups list
    function renderGroups() {
        groupsList.innerHTML = '';
        
        if (groups.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="5" class="text-center">Aucun groupe n\'a été créé</td>';
            groupsList.appendChild(row);
            return;
        }
        
        groups.forEach(group => {
            // Get class name
            const classObj = classes.find(cls => cls.id === group.classId);
            const className = classObj ? classObj.name : '-';
            
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${group.name}</td>
                <td>${className}</td>
                <td>${group.students.length}</td>
                <td>${group.description || '-'}</td>
                <td class="actions-cell">
                    <button class="action-btn view" title="Voir les élèves" data-id="${group.id}">
                        <i class="fas fa-user-graduate"></i>
                    </button>
                    <button class="action-btn edit" title="Modifier" data-id="${group.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete" title="Supprimer" data-id="${group.id}">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </td>
            `;
            
            // Add event listeners for action buttons
            const viewBtn = row.querySelector('.action-btn.view');
            const editBtn = row.querySelector('.action-btn.edit');
            const deleteBtn = row.querySelector('.action-btn.delete');
            
            viewBtn.addEventListener('click', () => viewGroupStudents(group.id));
            editBtn.addEventListener('click', () => editGroup(group.id));
            deleteBtn.addEventListener('click', () => confirmDeleteGroup(group.id));
            
            groupsList.appendChild(row);
        });
    }
    
    // Open add class modal
    function openAddClassModal() {
        addClassForm.reset();
        addClassModal.classList.add('active');
    }
    
    // Open add group modal
    function openAddGroupModal() {
        addGroupForm.reset();
        populateClassSelect(groupClassSelect);
        
        // Clear the students lists
        availableStudentsList.innerHTML = '';
        selectedStudentsList.innerHTML = '';
        selectedAvailableStudents = [];
        selectedGroupStudents = [];
        
        addGroupModal.classList.add('active');
    }
    
    // Open edit group modal
    function openEditGroupModal(group) {
        editGroupForm.reset();
        currentEditGroupId = group.id;
        
        // Populate form fields
        document.getElementById('edit-group-name').value = group.name;
        document.getElementById('edit-group-description').value = group.description || '';
        
        // Populate class select and select the current class
        populateClassSelect(editGroupClassSelect);
        editGroupClassSelect.value = group.classId;
        
        // Load available students for this class
        loadEditAvailableStudents(group.classId, group.students);
        
        // Populate the selected students list
        editSelectedStudentsList.innerHTML = '';
        selectedGroupStudents = [...group.students];
        
        // Add each student to the selected list
        const groupStudents = group.students.map(studentId => 
            students.find(student => student.id === studentId)
        ).filter(student => student); // Filter out any undefined values
        
        groupStudents.forEach(student => {
            const item = document.createElement('li');
            item.textContent = `${student.lastName} ${student.firstName}`;
            item.setAttribute('data-id', student.id);
            editSelectedStudentsList.appendChild(item);
        });
        
        editGroupModal.classList.add('active');
    }
    
    // Close all modals
    function closeAllModals() {
        addClassModal.classList.remove('active');
        addGroupModal.classList.remove('active');
        editGroupModal.classList.remove('active');
    }
    
    // Populate class select in the form
    function populateClassSelect(selectElement) {
        // Clear existing options except the default one
        while (selectElement.options.length > 1) {
            selectElement.remove(1);
        }
        
        // Add classes to the select
        classes.forEach(cls => {
            const option = document.createElement('option');
            option.value = cls.id;
            option.textContent = cls.name;
            selectElement.add(option);
        });
    }
    
    // Load available students for a class (create mode)
    function loadAvailableStudents(classId) {
        // Clear the lists
        availableStudentsList.innerHTML = '';
        selectedStudentsList.innerHTML = '';
        selectedAvailableStudents = [];
        selectedGroupStudents = [];
        
        if (!classId) return;
        
        // Get students for this class
        const classStudents = students.filter(student => student.class === classId);
        
        // Add each student to the available list
        classStudents.forEach(student => {
            const item = document.createElement('li');
            item.textContent = `${student.lastName} ${student.firstName}`;
            item.setAttribute('data-id', student.id);
            availableStudentsList.appendChild(item);
        });
    }
    
    // Load available students for a class (edit mode)
    function loadEditAvailableStudents(classId, selectedIds = []) {
        // Clear the available students list
        editAvailableStudentsList.innerHTML = '';
        selectedAvailableStudents = [];
        
        if (!classId) return;
        
        // Get students for this class
        const classStudents = students.filter(student => student.class === classId);
        
        // Add each student to the available list if not already in the group
        classStudents.forEach(student => {
            if (!selectedIds.includes(student.id)) {
                const item = document.createElement('li');
                item.textContent = `${student.lastName} ${student.firstName}`;
                item.setAttribute('data-id', student.id);
                editAvailableStudentsList.appendChild(item);
            }
        });
    }
    
    // Toggle student selection
    function toggleStudentSelection(element, listType) {
        const studentId = element.getAttribute('data-id');
        
        if (listType === 'available' || listType === 'edit-available') {
            // Add/remove from selected available students
            if (element.classList.contains('selected')) {
                element.classList.remove('selected');
                selectedAvailableStudents = selectedAvailableStudents.filter(id => id !== studentId);
            } else {
                element.classList.add('selected');
                selectedAvailableStudents.push(studentId);
            }
        } else {
            // Add/remove from selected group students
            if (element.classList.contains('selected')) {
                element.classList.remove('selected');
                selectedGroupStudents = selectedGroupStudents.filter(id => id !== studentId);
            } else {
                element.classList.add('selected');
                selectedGroupStudents.push(studentId);
            }
        }
    }
    
    // Transfer students between lists
    function transferStudents(action) {
        if (action === 'add') {
            // Move from available to selected
            const availableItems = Array.from(availableStudentsList.querySelectorAll('li.selected'));
            
            availableItems.forEach(item => {
                // Create new item in selected list
                const newItem = document.createElement('li');
                newItem.textContent = item.textContent;
                newItem.setAttribute('data-id', item.getAttribute('data-id'));
                selectedStudentsList.appendChild(newItem);
                
                // Remove from available list
                item.remove();
            });
            
            // Update selectedGroupStudents
            selectedGroupStudents = [...selectedGroupStudents, ...selectedAvailableStudents];
            selectedAvailableStudents = [];
        } else if (action === 'remove') {
            // Move from selected to available
            const selectedItems = Array.from(selectedStudentsList.querySelectorAll('li.selected'));
            
            selectedItems.forEach(item => {
                // Create new item in available list
                const newItem = document.createElement('li');
                newItem.textContent = item.textContent;
                newItem.setAttribute('data-id', item.getAttribute('data-id'));
                availableStudentsList.appendChild(newItem);
                
                // Remove from selected list
                item.remove();
            });
            
            // Update arrays
            const removedIds = selectedItems.map(item => item.getAttribute('data-id'));
            selectedAvailableStudents = [...selectedAvailableStudents, ...removedIds];
            selectedGroupStudents = selectedGroupStudents.filter(id => !removedIds.includes(id));
        } else if (action === 'edit-add') {
            // Move from available to selected (edit mode)
            const availableItems = Array.from(editAvailableStudentsList.querySelectorAll('li.selected'));
            
            availableItems.forEach(item => {
                // Create new item in selected list
                const newItem = document.createElement('li');
                newItem.textContent = item.textContent;
                newItem.setAttribute('data-id', item.getAttribute('data-id'));
                editSelectedStudentsList.appendChild(newItem);
                
                // Remove from available list
                item.remove();
            });
            
            // Update selectedGroupStudents
            selectedGroupStudents = [...selectedGroupStudents, ...selectedAvailableStudents];
            selectedAvailableStudents = [];
        } else if (action === 'edit-remove') {
            // Move from selected to available (edit mode)
            const selectedItems = Array.from(editSelectedStudentsList.querySelectorAll('li.selected'));
            
            selectedItems.forEach(item => {
                // Create new item in available list
                const newItem = document.createElement('li');
                newItem.textContent = item.textContent;
                newItem.setAttribute('data-id', item.getAttribute('data-id'));
                editAvailableStudentsList.appendChild(newItem);
                
                // Remove from selected list
                item.remove();
            });
            
            // Update arrays
            const removedIds = selectedItems.map(item => item.getAttribute('data-id'));
            selectedAvailableStudents = [...selectedAvailableStudents, ...removedIds];
            selectedGroupStudents = selectedGroupStudents.filter(id => !removedIds.includes(id));
        }
    }
    
    // Filter students in the list
    function filterStudents(query, mode) {
        const list = mode === 'create' ? availableStudentsList : editAvailableStudentsList;
        const items = list.querySelectorAll('li');
        
        query = query.toLowerCase();
        
        items.forEach(item => {
            const text = item.textContent.toLowerCase();
            if (text.includes(query)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    // Add class
    function addClass() {
        const classId = document.getElementById('class-id').value;
        const className = document.getElementById('class-name').value;
        const classTeacher = document.getElementById('class-teacher').value;
        
        // Check if class ID already exists
        if (classes.some(cls => cls.id === classId)) {
            alert('Une classe avec cet ID existe déjà.');
            return;
        }
        
        const newClass = {
            id: classId,
            name: className,
            teacher: classTeacher
        };
        
        classes.push(newClass);
        saveData();
        
        // Reset form
        addClassForm.reset();
        closeAllModals();
        
        // Refresh the classes view
        renderClasses();
    }
    
    // Add group
    function addGroup() {
        const groupName = document.getElementById('group-name').value;
        const classId = document.getElementById('group-class').value;
        const description = document.getElementById('group-description').value;
        
        // Ensure a class is selected
        if (!classId) {
            alert('Veuillez sélectionner une classe pour ce groupe.');
            return;
        }
        
        // Collect group students from the selected list
        const groupStudentIds = Array.from(selectedStudentsList.querySelectorAll('li'))
            .map(item => item.getAttribute('data-id'));
        
        // Create new group
        const newGroup = {
            id: Date.now().toString(), // Generate a unique ID
            name: groupName,
            classId: classId,
            description: description,
            students: groupStudentIds
        };
        
        groups.push(newGroup);
        saveData();
        
        // Reset form
        addGroupForm.reset();
        closeAllModals();
        
        // Switch to the groups tab
        document.querySelector('.tab-btn[data-tab="groups"]').click();
    }
    
    // Edit class
    function editClass(classId) {
        const cls = classes.find(c => c.id === classId);
        if (!cls) return;
        
        // For now, we'll reuse the add class modal but pre-populate fields
        document.getElementById('class-id').value = cls.id;
        document.getElementById('class-name').value = cls.name;
        document.getElementById('class-teacher').value = cls.teacher || '';
        
        // Show modal
        addClassModal.classList.add('active');
    }
    
    // Edit group
    function editGroup(groupId) {
        const group = groups.find(g => g.id === groupId);
        if (!group) return;
        
        openEditGroupModal(group);
    }
    
    // Update group (save edited group)
    function updateGroup() {
        // Get values from form
        const groupName = document.getElementById('edit-group-name').value;
        const classId = document.getElementById('edit-group-class').value;
        const description = document.getElementById('edit-group-description').value;
        
        // Find the group to update
        const groupIndex = groups.findIndex(g => g.id === currentEditGroupId);
        if (groupIndex === -1) return;
        
        // Update group data
        groups[groupIndex] = {
            ...groups[groupIndex],
            name: groupName,
            classId: classId,
            description: description,
            students: selectedGroupStudents
        };
        
        saveData();
        
        // Close modal and refresh
        closeAllModals();
        renderGroups();
    }
    
    // Confirm delete class
    function confirmDeleteClass(classId) {
        // Check if the class has students
        const hasStudents = students.some(student => student.class === classId);
        
        // Check if the class is used in any groups
        const usedInGroups = groups.some(group => group.classId === classId);
        
        if (hasStudents || usedInGroups) {
            let message = "Attention: ";
            if (hasStudents) message += "Cette classe contient des élèves. ";
            if (usedInGroups) message += "Cette classe est utilisée dans des groupes. ";
            message += "Êtes-vous sûr de vouloir la supprimer ?";
            
            if (!confirm(message)) return;
        } else {
            if (!confirm("Êtes-vous sûr de vouloir supprimer cette classe ?")) return;
        }
        
        // Delete the class
        classes = classes.filter(cls => cls.id !== classId);
        saveData();
        renderClasses();
    }
    
    // Confirm delete group
    function confirmDeleteGroup(groupId) {
        if (!confirm("Êtes-vous sûr de vouloir supprimer ce groupe ?")) return;
        
        // Delete the group
        groups = groups.filter(group => group.id !== groupId);
        saveData();
        renderGroups();
    }
    
    // View class students
    function viewClassStudents(classId) {
        // For now, we'll just redirect to the classes-eleves page
        window.location.href = `classes-eleves.html?class=${classId}`;
    }
    
    // View group students
    function viewGroupStudents(groupId) {
        const group = groups.find(g => g.id === groupId);
        if (!group) return;
        
        const classObj = classes.find(cls => cls.id === group.classId);
        const className = classObj ? classObj.name : 'Inconnue';
        
        // Get the student details
        const groupStudents = group.students.map(studentId => 
            students.find(student => student.id === studentId)
        ).filter(student => student); // Filter out any undefined values
        
        // Format the student list for display
        const studentList = groupStudents.map(student => 
            `${student.lastName} ${student.firstName}`
        ).join('\n');
        
        // Show a simple alert for now
        alert(`Groupe: ${group.name}\nClasse: ${className}\n\nÉlèves:\n${studentList || 'Aucun élève dans ce groupe'}`);
    }

    // Export data to GitHub
    async function exportToGithub() {
        try {
            // Import the functions from gists-sync.js
            const module = await import('./gists-sync.js').catch(e => {
                console.error('Error importing gists-sync.js:', e);
                return null;
            });
            
            if (!module) return;
            
            const { saveToGist } = module;
            
            // Collect all data
            const dataToUpload = {
                userData: JSON.parse(localStorage.getItem('user_data') || '{}'),
                schedules: JSON.parse(localStorage.getItem('imported_calendars') || '[]'),
                classes: classes,
                evaluations: JSON.parse(localStorage.getItem('evaluations_data') || '[]'),
                students: students,
                grades: JSON.parse(localStorage.getItem('grades_data') || '{}'),
                groups: groups
            };
            
            // Save to GitHub
            await saveToGist(dataToUpload);
            
            // Update last sync date
            localStorage.setItem('last_sync_date', new Date().toISOString());
            
            console.log('Classes/Groups data exported to GitHub Gists successfully');
        } catch (error) {
            console.error('Error exporting classes/groups data to GitHub:', error);
        }
    }
});