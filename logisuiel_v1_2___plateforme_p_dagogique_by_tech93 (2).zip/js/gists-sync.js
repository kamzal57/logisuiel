// GitHub Gists synchronization utility
const GIST_ID = 'b715a0f2679543f6a41f3d8ed8a38140';
const GIST_TOKEN = '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';

// Function to fetch data from the Gist
async function fetchFromGist() {
    try {
        const response = await fetch(`https://api.github.com/gists/${GIST_ID}`, {
            headers: {
                'Authorization': `token ${GIST_TOKEN}`
            }
        });
        
        if (!response.ok) {
            throw new Error(`GitHub API error: ${response.status}`);
        }
        
        const gistData = await response.json();
        
        // Extract content from files
        const files = gistData.files;
        const appData = {};
        
        // Process each file in the gist
        for (const filename in files) {
            if (filename.endsWith('.json')) {
                try {
                    appData[filename.replace('.json', '')] = JSON.parse(files[filename].content);
                } catch (e) {
                    console.error(`Error parsing JSON in ${filename}:`, e);
                }
            }
        }
        
        return appData;
    } catch (error) {
        console.error('Error fetching from Gist:', error);
        throw error;
    }
}

// Function to save data to the Gist
async function saveToGist(data) {
    try {
        // Prepare files object for Gist update
        const files = {};
        
        // Convert each data section to a separate file
        for (const section in data) {
            files[`${section}.json`] = {
                content: JSON.stringify(data[section], null, 2)
            };
        }
        
        // Send update to GitHub
        const response = await fetch(`https://api.github.com/gists/${GIST_ID}`, {
            method: 'PATCH',
            headers: {
                'Authorization': `token ${GIST_TOKEN}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ files })
        });
        
        if (!response.ok) {
            throw new Error(`GitHub API error: ${response.status}`);
        }
        
        return await response.json();
    } catch (error) {
        console.error('Error saving to Gist:', error);
        throw error;
    }
}

// Check if Gist connection is valid
async function testGistConnection() {
    try {
        const response = await fetch(`https://api.github.com/gists/${GIST_ID}`, {
            headers: {
                'Authorization': `token ${GIST_TOKEN}`
            }
        });
        
        return response.ok;
    } catch (error) {
        console.error('Error testing Gist connection:', error);
        return false;
    }
}

export { fetchFromGist, saveToGist, testGistConnection };