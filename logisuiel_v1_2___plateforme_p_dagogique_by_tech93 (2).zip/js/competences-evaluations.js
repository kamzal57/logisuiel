document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const evalsList = document.getElementById('comp-evaluations-list');
    const filterClass = document.getElementById('filter-class');
    const filterPeriod = document.getElementById('filter-period');
    const filterSubject = document.getElementById('filter-subject');
    const btnAddEval = document.getElementById('btn-add-comp-eval');
    const evalModal = document.getElementById('comp-eval-modal');
    const assessmentModal = document.getElementById('comp-assessment-modal');
    const evalForm = document.getElementById('comp-eval-form');
    const closeButtons = document.querySelectorAll('.close-btn');
    const cancelEvalBtn = document.getElementById('cancel-comp-eval');
    const cancelAssessBtn = document.getElementById('cancel-comp-assess');
    const saveAssessBtn = document.getElementById('save-comp-assess');
    const modalTitle = document.getElementById('modal-title');
    const prevPageBtn = document.getElementById('prev-page');
    const nextPageBtn = document.getElementById('next-page');
    const pageInfo = document.getElementById('page-info');
    const compEvalReferential = document.getElementById('comp-eval-referential');
    const availableCompetenciesList = document.getElementById('available-competencies-list');
    const selectedCompetenciesList = document.getElementById('selected-competencies-list');
    const addCompetencyBtn = document.getElementById('add-competency');
    const removeCompetencyBtn = document.getElementById('remove-competency');
    const searchCompetencies = document.getElementById('search-competencies');

    // State
    let compEvaluations = JSON.parse(localStorage.getItem('comp_evaluations_data') || '[]');
    let compAssessments = JSON.parse(localStorage.getItem('comp_assessments_data') || '{}');
    let referentials = JSON.parse(localStorage.getItem('referentials_data') || '[]');
    let competences = JSON.parse(localStorage.getItem('competences_data') || '[]');
    let students = {};
    
    // Pagination
    let currentPage = 1;
    const itemsPerPage = 10;
    
    // Filter settings
    let currentFilter = { class: 'all', period: 'all', subject: 'all' };
    
    // Current editing state
    let currentEvalId = null;
    let selectedAvailableCompetencies = [];
    let selectedChosenCompetencies = [];
    
    // Initialize
    initialize();
    
    function initialize() {
        // Load students by class
        loadStudents();
        
        // Render the initial evaluations list
        renderEvaluations();
        
        // Set up event listeners
        setupEventListeners();

        // Populate class filter and referential dropdown
        populateClassFilter();
        populateReferentialDropdown();
        
        console.log('Competency evaluations loaded:', compEvaluations.length);
    }
    
    // Load students by class
    function loadStudents() {
        const studentData = JSON.parse(localStorage.getItem('students_data') || '[]');
        studentData.forEach(student => {
            if(!students[student.class]){
                students[student.class] = [];
            }
            students[student.class].push(student);
        });
    }
    
    function setupEventListeners() {
        // Filter changes
        filterClass.addEventListener('change', function() {
            currentFilter.class = this.value;
            currentPage = 1;
            renderEvaluations();
        });
        
        filterPeriod.addEventListener('change', function() {
            currentFilter.period = this.value;
            currentPage = 1;
            renderEvaluations();
        });
        
        filterSubject.addEventListener('change', function() {
            currentFilter.subject = this.value;
            currentPage = 1;
            renderEvaluations();
        });
        
        // Pagination
        prevPageBtn.addEventListener('click', function() {
            if (currentPage > 1) {
                currentPage--;
                renderEvaluations();
            }
        });
        
        nextPageBtn.addEventListener('click', function() {
            const filteredItems = getFilteredEvaluations();
            const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
            
            if (currentPage < totalPages) {
                currentPage++;
                renderEvaluations();
            }
        });
        
        // Add evaluation button
        btnAddEval.addEventListener('click', function() {
            openCreateEvalModal();
        });
        
        // Close modals
        closeButtons.forEach(button => {
            button.addEventListener('click', function() {
                closeAllModals();
            });
        });
        
        // Cancel buttons
        cancelEvalBtn.addEventListener('click', function() {
            closeAllModals();
        });
        
        cancelAssessBtn.addEventListener('click', function() {
            closeAllModals();
        });
        
        // Form submission
        evalForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveEvaluation();
        });
        
        // Save assessments
        saveAssessBtn.addEventListener('click', function() {
            saveAssessmentData();
        });
        
        // Referential change
        compEvalReferential.addEventListener('change', function() {
            loadCompetenciesForReferential(this.value);
        });
        
        // Competency selection
        addCompetencyBtn.addEventListener('click', function() {
            transferCompetencies('add');
        });
        
        removeCompetencyBtn.addEventListener('click', function() {
            transferCompetencies('remove');
        });
        
        // Search competencies
        searchCompetencies.addEventListener('input', function() {
            filterCompetencies(this.value);
        });
    }
    
    function getFilteredEvaluations() {
        return compEvaluations.filter(eval => {
            // Apply class filter
            if (currentFilter.class !== 'all' && eval.class !== currentFilter.class) {
                return false;
            }
            
            // Apply period filter
            if (currentFilter.period !== 'all' && eval.period !== currentFilter.period) {
                return false;
            }
            
            // Apply subject filter
            if (currentFilter.subject !== 'all' && eval.subject !== currentFilter.subject) {
                return false;
            }
            
            return true;
        });
    }
    
    function getPaginatedEvaluations() {
        const filteredItems = getFilteredEvaluations();
        const start = (currentPage - 1) * itemsPerPage;
        const end = start + itemsPerPage;
        
        return filteredItems.slice(start, end);
    }
    
    function updatePagination() {
        const filteredItems = getFilteredEvaluations();
        const totalPages = Math.ceil(filteredItems.length / itemsPerPage);
        
        pageInfo.textContent = `Page ${currentPage} sur ${totalPages || 1}`;
        
        prevPageBtn.disabled = currentPage <= 1;
        nextPageBtn.disabled = currentPage >= totalPages;
    }
    
    function renderEvaluations() {
        const paginatedItems = getPaginatedEvaluations();
        
        // Clear current list
        evalsList.innerHTML = '';
        
        if (paginatedItems.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="8" class="text-center">Aucune évaluation de compétences trouvée</td>';
            evalsList.appendChild(row);
        } else {
            // Add each evaluation to the list
            paginatedItems.forEach(eval => {
                const row = document.createElement('tr');
                
                // Format date
                const date = new Date(eval.date);
                const formattedDate = `${date.getDate().toString().padStart(2, '0')}/${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getFullYear()}`;
                
                // Status label
                let statusLabel = '';
                switch(eval.status) {
                    case 'draft':
                        statusLabel = '<span class="eval-status draft">Brouillon</span>';
                        break;
                    case 'in-progress':
                        statusLabel = '<span class="eval-status in-progress">En cours</span>';
                        break;
                    case 'completed':
                        statusLabel = '<span class="eval-status completed">Terminé</span>';
                        break;
                }
                
                // Create competence count badge
                const competenceCount = eval.competencies ? eval.competencies.length : 0;
                const competenceBadge = `<span class="competence-count">${competenceCount}</span>`;
                
                row.innerHTML = `
                    <td>${formattedDate}</td>
                    <td>${eval.title}</td>
                    <td>${eval.class}</td>
                    <td>${eval.subjectName || eval.subject}</td>
                    <td>${eval.periodName || eval.period}</td>
                    <td>${competenceBadge}</td>
                    <td>${statusLabel}</td>
                    <td class="actions-cell">
                        <button class="action-btn grades" title="Saisir les niveaux de compétences" data-id="${eval.id}">
                            <i class="fas fa-clipboard-list"></i>
                        </button>
                        <button class="action-btn edit" title="Modifier" data-id="${eval.id}">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="action-btn delete" title="Supprimer" data-id="${eval.id}">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </td>
                `;
                
                // Add event listeners for action buttons
                const editBtn = row.querySelector('.action-btn.edit');
                const deleteBtn = row.querySelector('.action-btn.delete');
                const assessBtn = row.querySelector('.action-btn.grades');
                
                editBtn.addEventListener('click', function() {
                    const evalId = parseInt(this.getAttribute('data-id'));
                    openEditEvalModal(evalId);
                });
                
                deleteBtn.addEventListener('click', function() {
                    const evalId = parseInt(this.getAttribute('data-id'));
                    confirmDeleteEvaluation(evalId);
                });
                
                assessBtn.addEventListener('click', function() {
                    const evalId = parseInt(this.getAttribute('data-id'));
                    openAssessmentModal(evalId);
                });
                
                evalsList.appendChild(row);
            });
        }
        
        // Update pagination
        updatePagination();
    }
    
    function openCreateEvalModal() {
        // Reset form
        evalForm.reset();
        availableCompetenciesList.innerHTML = '';
        selectedCompetenciesList.innerHTML = '';
        selectedAvailableCompetencies = [];
        selectedChosenCompetencies = [];
        
        // Set modal title
        modalTitle.textContent = 'Créer une évaluation de compétences';
        
        // Reset current eval ID
        currentEvalId = null;
        
        // Show modal
        evalModal.classList.add('active');
    }
    
    function openEditEvalModal(evalId) {
        // Find the evaluation
        const evaluation = compEvaluations.find(eval => eval.id === evalId);
        if (!evaluation) return;
        
        // Set current eval ID
        currentEvalId = evalId;
        
        // Set modal title
        modalTitle.textContent = 'Modifier l\'évaluation de compétences';
        
        // Populate form fields
        document.getElementById('comp-eval-title').value = evaluation.title;
        document.getElementById('comp-eval-date').value = evaluation.date;
        document.getElementById('comp-eval-class').value = evaluation.class;
        document.getElementById('comp-eval-subject').value = evaluation.subject;
        document.getElementById('comp-eval-period').value = evaluation.period;
        document.getElementById('comp-eval-referential').value = evaluation.referentialId;
        document.getElementById('comp-eval-description').value = evaluation.description || '';
        
        // Load competencies
        loadCompetenciesForReferential(evaluation.referentialId, evaluation.competencies);
        
        // Show modal
        evalModal.classList.add('active');
    }
    
    function saveEvaluation() {
        // Get form values
        const title = document.getElementById('comp-eval-title').value;
        const date = document.getElementById('comp-eval-date').value;
        const classValue = document.getElementById('comp-eval-class').value;
        const subject = document.getElementById('comp-eval-subject').value;
        const period = document.getElementById('comp-eval-period').value;
        const referentialId = document.getElementById('comp-eval-referential').value;
        const description = document.getElementById('comp-eval-description').value;
        
        // Get subject name, period name, and referential name
        const subjectName = document.getElementById('comp-eval-subject').options[document.getElementById('comp-eval-subject').selectedIndex].text;
        const periodName = document.getElementById('comp-eval-period').options[document.getElementById('comp-eval-period').selectedIndex].text;
        const referential = referentials.find(ref => ref.id === referentialId);
        const referentialName = referential ? referential.name : 'Inconnu';
        
        // Get selected competencies from the list
        const selectedCompetencyIds = [];
        const items = selectedCompetenciesList.querySelectorAll('li');
        items.forEach(item => {
            selectedCompetencyIds.push(item.getAttribute('data-id'));
        });
        
        if (selectedCompetencyIds.length === 0) {
            alert('Veuillez sélectionner au moins une compétence.');
            return;
        }
        
        if (currentEvalId === null) {
            // Create new evaluation
            const newId = Math.max(0, ...compEvaluations.map(e => e.id)) + 1;
            
            const newEvaluation = {
                id: newId,
                title,
                date,
                class: classValue,
                subject,
                subjectName,
                period,
                periodName,
                referentialId,
                referentialName,
                competencies: selectedCompetencyIds,
                status: 'draft',
                description
            };
            
            compEvaluations.push(newEvaluation);
            
            // Initialize empty assessments for this evaluation
            compAssessments[newId] = [];
        } else {
            // Update existing evaluation
            const evaluation = compEvaluations.find(eval => eval.id === currentEvalId);
            if (evaluation) {
                evaluation.title = title;
                evaluation.date = date;
                evaluation.class = classValue;
                evaluation.subject = subject;
                evaluation.subjectName = subjectName;
                evaluation.period = period;
                evaluation.periodName = periodName;
                evaluation.referentialId = referentialId;
                evaluation.referentialName = referentialName;
                evaluation.competencies = selectedCompetencyIds;
                evaluation.description = description;
            }
        }
        
        // Save evaluations to local storage
        localStorage.setItem('comp_evaluations_data', JSON.stringify(compEvaluations));
        
        // Close modal
        closeAllModals();
        
        // Refresh list
        renderEvaluations();
        
        // Export data to GitHub
        exportToGithub();
    }
    
    function confirmDeleteEvaluation(evalId) {
        // In a real app, this would show a confirmation dialog
        if (confirm('Êtes-vous sûr de vouloir supprimer cette évaluation de compétences ?')) {
            deleteEvaluation(evalId);
        }
    }
    
    function deleteEvaluation(evalId) {
        // Remove the evaluation from the array
        compEvaluations = compEvaluations.filter(eval => eval.id !== evalId);
        
        // Remove associated assessments
        delete compAssessments[evalId];
        
        // Save evaluations to local storage
        localStorage.setItem('comp_evaluations_data', JSON.stringify(compEvaluations));
        localStorage.setItem('comp_assessments_data', JSON.stringify(compAssessments));
        
        // Refresh list
        renderEvaluations();
        
        // Export data to GitHub
        exportToGithub();
    }
    
    function openAssessmentModal(evalId) {
        // Find the evaluation
        const evaluation = compEvaluations.find(eval => eval.id === evalId);
        if (!evaluation) return;
        
        // Set current eval ID
        currentEvalId = evalId;
        
        // Set modal title
        document.getElementById('comp-assessment-modal-title').textContent = `Saisie des niveaux de compétences - ${evaluation.title}`;
        
        // Set evaluation info
        document.getElementById('comp-assess-class').textContent = evaluation.class;
        document.getElementById('comp-assess-subject').textContent = evaluation.subjectName;
        document.getElementById('comp-assess-period').textContent = evaluation.periodName;
        
        // Load and render the assessment list
        renderAssessmentList(evalId, evaluation.competencies, evaluation.class);
        
        // Show modal
        assessmentModal.classList.add('active');
    }
    
    function renderAssessmentList(evalId, competencyIds, classValue) {
        const assessList = document.getElementById('comp-assess-list');
        const assessTable = document.querySelector('.comp-assess-table thead tr');
        
        // Clear existing headers except first and last two columns
        while (assessTable.children.length > 3) {
            assessTable.removeChild(assessTable.children[1]);
        }
        
        // Load competencies
        const evalCompetencies = competencyIds.map(id => {
            return competences.find(comp => comp.id === id);
        }).filter(comp => comp); // Filter out undefined values
        
        // Add competency headers
        evalCompetencies.forEach(comp => {
            const th = document.createElement('th');
            th.className = 'comp-assess-level';
            th.setAttribute('data-id', comp.id);
            th.setAttribute('title', comp.name);
            th.innerHTML = `
                <div class="competence-name">${comp.code}</div>
            `;
            // Insert before the Observation column
            assessTable.insertBefore(th, assessTable.children[assessTable.children.length - 2]);
        });
        
        // Clear assessment list
        assessList.innerHTML = '';
        
        // Ensure assessments data structure exists
        if (!compAssessments[evalId]) {
            compAssessments[evalId] = [];
        }
        
        // Get students for this class
        if (students[classValue]) {
            students[classValue].forEach(student => {
                // Find or create assessment record for this student
                let studentAssessment = compAssessments[evalId].find(a => a.studentId === student.id);
                
                if (!studentAssessment) {
                    studentAssessment = {
                        studentId: student.id,
                        firstName: student.firstName,
                        lastName: student.lastName,
                        competencies: {},
                        comment: '',
                        absent: false
                    };
                    
                    // Initialize empty competency assessments
                    evalCompetencies.forEach(comp => {
                        studentAssessment.competencies[comp.id] = null; // null = not assessed
                    });
                    
                    compAssessments[evalId].push(studentAssessment);
                }
                
                // Add student row
                const row = document.createElement('tr');
                row.dataset.studentId = student.id;
                
                // Create student name cell
                const nameCell = document.createElement('td');
                nameCell.textContent = `${student.lastName} ${student.firstName}`;
                row.appendChild(nameCell);
                
                // Create competency level cells
                evalCompetencies.forEach(comp => {
                    const levelCell = document.createElement('td');
                    levelCell.className = 'assessment-cell';
                    levelCell.dataset.competencyId = comp.id;
                    
                    // Current level (or null if not set)
                    const currentLevel = studentAssessment.competencies[comp.id];
                    
                    // Create level selector
                    const levelSelector = document.createElement('div');
                    levelSelector.className = 'comp-assess-level-selector';
                    
                    // Create level options
                    const levels = [
                        { value: 1, class: 'insufficient', title: 'Insuffisant' },
                        { value: 2, class: 'fragile', title: 'Fragile' },
                        { value: 3, class: 'satisfactory', title: 'Satisfaisant' },
                        { value: 4, class: 'very-good', title: 'Très satisfaisant' }
                    ];
                    
                    levels.forEach(level => {
                        const option = document.createElement('div');
                        option.className = `level-option ${level.class}`;
                        if (currentLevel === level.value) {
                            option.classList.add('selected');
                        }
                        option.setAttribute('title', level.title);
                        option.dataset.value = level.value;
                        
                        // Add click handler
                        option.addEventListener('click', function() {
                            // Remove selected class from all options in this cell
                            levelCell.querySelectorAll('.level-option').forEach(opt => {
                                opt.classList.remove('selected');
                            });
                            
                            // Add selected class to clicked option
                            this.classList.add('selected');
                            
                            // Update level in data
                            studentAssessment.competencies[comp.id] = parseInt(this.dataset.value);
                        });
                        
                        levelSelector.appendChild(option);
                    });
                    
                    levelCell.appendChild(levelSelector);
                    row.appendChild(levelCell);
                });
                
                // Create comment cell
                const commentCell = document.createElement('td');
                const commentInput = document.createElement('input');
                commentInput.type = 'text';
                commentInput.placeholder = 'Observation';
                commentInput.value = studentAssessment.comment || '';
                commentInput.addEventListener('change', function() {
                    studentAssessment.comment = this.value;
                });
                commentCell.appendChild(commentInput);
                row.appendChild(commentCell);
                
                // Create absent checkbox cell
                const absentCell = document.createElement('td');
                absentCell.className = 'absent-checkbox';
                const absentInput = document.createElement('input');
                absentInput.type = 'checkbox';
                absentInput.checked = studentAssessment.absent;
                absentInput.addEventListener('change', function() {
                    studentAssessment.absent = this.checked;
                    
                    // Disable/enable assessment cells based on absence
                    const assessmentCells = row.querySelectorAll('.assessment-cell');
                    assessmentCells.forEach(cell => {
                        if (this.checked) {
                            cell.classList.add('disabled');
                            // Reset competency levels for absent student
                            const competencyId = cell.dataset.competencyId;
                            studentAssessment.competencies[competencyId] = null;
                            
                            // Remove selection
                            cell.querySelectorAll('.level-option').forEach(opt => {
                                opt.classList.remove('selected');
                            });
                        } else {
                            cell.classList.remove('disabled');
                        }
                    });
                });
                absentCell.appendChild(absentInput);
                row.appendChild(absentCell);
                
                // Add the row to the list
                assessList.appendChild(row);
                
                // If student is absent, disable assessment cells
                if (studentAssessment.absent) {
                    const assessmentCells = row.querySelectorAll('.assessment-cell');
                    assessmentCells.forEach(cell => {
                        cell.classList.add('disabled');
                    });
                }
            });
        }
    }
    
    function saveAssessmentData() {
        // Update evaluation status
        const evaluation = compEvaluations.find(eval => eval.id === currentEvalId);
        if (evaluation) {
            // Check if all students have assessments
            const assessments = compAssessments[currentEvalId];
            if (assessments) {
                // Check if all students have at least one competency assessed or are marked absent
                const allAssessed = assessments.every(studentAssessment => {
                    if (studentAssessment.absent) return true;
                    
                    // Check if at least one competency is assessed
                    return Object.values(studentAssessment.competencies).some(level => level !== null);
                });
                
                if (allAssessed) {
                    evaluation.status = 'completed';
                } else if (assessments.some(studentAssessment => 
                    studentAssessment.absent || Object.values(studentAssessment.competencies).some(level => level !== null))) {
                    evaluation.status = 'in-progress';
                } else {
                    evaluation.status = 'draft';
                }
            }
        }
        
        // Save all data to local storage
        localStorage.setItem('comp_evaluations_data', JSON.stringify(compEvaluations));
        localStorage.setItem('comp_assessments_data', JSON.stringify(compAssessments));
        
        // Close modal
        closeAllModals();
        
        // Refresh list
        renderEvaluations();
        
        // Export data to GitHub
        exportToGithub();
    }
    
    function loadCompetenciesForReferential(referentialId, selectedIds = []) {
        // Clear both lists
        availableCompetenciesList.innerHTML = '';
        selectedCompetenciesList.innerHTML = '';
        
        if (!referentialId) return;
        
        // Reset selection arrays
        selectedAvailableCompetencies = [];
        selectedChosenCompetencies = [];
        
        // Get competencies for this referential
        const refCompetencies = competences.filter(comp => comp.referentialId === referentialId);
        
        // Sort competencies by code
        refCompetencies.sort((a, b) => a.code.localeCompare(b.code));
        
        // Add competencies to appropriate lists
        refCompetencies.forEach(comp => {
            const item = document.createElement('li');
            item.textContent = `${comp.code} - ${comp.name}`;
            item.setAttribute('data-id', comp.id);
            
            // Add click handler for selection
            item.addEventListener('click', function() {
                this.classList.toggle('selected');
                const compId = this.getAttribute('data-id');
                
                if (this.classList.contains('selected')) {
                    selectedAvailableCompetencies.push(compId);
                } else {
                    selectedAvailableCompetencies = selectedAvailableCompetencies.filter(id => id !== compId);
                }
            });
            
            // Add to appropriate list based on if it's already selected
            if (selectedIds && selectedIds.includes(comp.id)) {
                selectedCompetenciesList.appendChild(item);
            } else {
                availableCompetenciesList.appendChild(item);
            }
        });
    }
    
    function transferCompetencies(direction) {
        if (direction === 'add') {
            // Get selected items from available list
            const selectedItems = availableCompetenciesList.querySelectorAll('li.selected');
            
            // Move to selected list
            selectedItems.forEach(item => {
                item.classList.remove('selected');
                selectedCompetenciesList.appendChild(item);
                
                // Update click handler
                item.onclick = function() {
                    this.classList.toggle('selected');
                    const compId = this.getAttribute('data-id');
                    
                    if (this.classList.contains('selected')) {
                        selectedChosenCompetencies.push(compId);
                    } else {
                        selectedChosenCompetencies = selectedChosenCompetencies.filter(id => id !== compId);
                    }
                };
            });
            
            // Clear selection array
            selectedAvailableCompetencies = [];
        } else if (direction === 'remove') {
            // Get selected items from chosen list
            const selectedItems = selectedCompetenciesList.querySelectorAll('li.selected');
            
            // Move to available list
            selectedItems.forEach(item => {
                item.classList.remove('selected');
                availableCompetenciesList.appendChild(item);
                
                // Update click handler
                item.onclick = function() {
                    this.classList.toggle('selected');
                    const compId = this.getAttribute('data-id');
                    
                    if (this.classList.contains('selected')) {
                        selectedAvailableCompetencies.push(compId);
                    } else {
                        selectedAvailableCompetencies = selectedAvailableCompetencies.filter(id => id !== compId);
                    }
                };
            });
            
            // Clear selection array
            selectedChosenCompetencies = [];
        }
    }
    
    function filterCompetencies(search) {
        if (!search) {
            // Show all competencies
            availableCompetenciesList.querySelectorAll('li').forEach(item => {
                item.style.display = '';
            });
            return;
        }
        
        // Filter by search term
        search = search.toLowerCase();
        availableCompetenciesList.querySelectorAll('li').forEach(item => {
            const text = item.textContent.toLowerCase();
            if (text.includes(search)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });
    }
    
    function closeAllModals() {
        evalModal.classList.remove('active');
        assessmentModal.classList.remove('active');
    }
    
    function populateClassFilter() {
        const filterClass = document.getElementById('filter-class');
        const evalClass = document.getElementById('comp-eval-class');
        
        // Load classes from local storage
        const classes = JSON.parse(localStorage.getItem('classes_data') || '[]');
        
        // Clear existing options, keeping only the "all" option in filterClass
        while (filterClass.options.length > 1) {
            filterClass.remove(1);
        }

        // Clear existing options
        while (evalClass.options.length > 0) {
            evalClass.remove(0);
        }
        
        // Add a default selection
        const defaultOption = document.createElement('option');
        defaultOption.value = "";
        defaultOption.textContent = "Sélectionnez";
        evalClass.add(defaultOption);

        // Add classes to both filterClass and evalClass
        classes.forEach(cls => {
            const filterOption = document.createElement('option');
            filterOption.value = cls.id;
            filterOption.textContent = cls.name;
            filterClass.add(filterOption);

            const evalOption = document.createElement('option');
            evalOption.value = cls.id;
            evalOption.textContent = cls.name;
            evalClass.add(evalOption);
        });
    }
    
    function populateReferentialDropdown() {
        // Clear existing options
        while (compEvalReferential.options.length > 1) {
            compEvalReferential.remove(1);
        }
        
        // Add referentials
        referentials.forEach(ref => {
            const option = document.createElement('option');
            option.value = ref.id;
            option.textContent = `${ref.name} (${getSubjectName(ref.subject)} - ${getLevelName(ref.level)})`;
            compEvalReferential.add(option);
        });
    }
    
    // Helper functions
    function getSubjectName(subjectCode) {
        switch (subjectCode) {
            case 'MATH': return 'Mathématiques';
            case 'FRA': return 'Français';
            case 'HG': return 'Histoire-Géographie';
            case 'SVT': return 'SVT';
            case 'PHY': return 'Physique-Chimie';
            case 'LV1': return 'Langue Vivante 1';
            case 'LV2': return 'Langue Vivante 2';
            case 'EPS': return 'EPS';
            case 'TECH': return 'Technologie';
            case 'ART': return 'Arts Plastiques';
            case 'MUS': return 'Éducation Musicale';
            case 'OTHER': return 'Autre';
            default: return subjectCode;
        }
    }

    function getLevelName(levelCode) {
        switch (levelCode) {
            case '6': return '6ème';
            case '5': return '5ème';
            case '4': return '4ème';
            case '3': return '3ème';
            case '2': return '2nde';
            case '1': return '1ère';
            case 'T': return 'Terminale';
            case 'cycle3': return 'Cycle 3';
            case 'cycle4': return 'Cycle 4';
            case 'lycee': return 'Lycée';
            default: return levelCode;
        }
    }

    // Export data to GitHub
    async function exportToGithub() {
        try {
            // Import the functions from gists-sync.js
            const module = await import('./gists-sync.js').catch(e => {
                console.error('Error importing gists-sync.js:', e);
                return null;
            });
            
            if (!module) return;
            
            const { saveToGist } = module;
            
            // Collect all data
            const dataToUpload = {
                userData: JSON.parse(localStorage.getItem('user_data') || '{}'),
                schedules: JSON.parse(localStorage.getItem('imported_calendars') || '[]'),
                classes: JSON.parse(localStorage.getItem('classes_data') || '[]'),
                evaluations: JSON.parse(localStorage.getItem('evaluations_data') || '[]'),
                students: JSON.parse(localStorage.getItem('students_data') || '[]'),
                grades: JSON.parse(localStorage.getItem('grades_data') || '{}'),
                groups: JSON.parse(localStorage.getItem('groups_data') || '[]'),
                referentials: referentials,
                competences: competences,
                compEvaluations: compEvaluations,
                compAssessments: compAssessments
            };
            
            // Save to GitHub
            await saveToGist(dataToUpload);
            
            // Update last sync date
            localStorage.setItem('last_sync_date', new Date().toISOString());
            
            console.log('Competency evaluation data exported to GitHub Gists successfully');
        } catch (error) {
            console.error('Error exporting competency evaluation data to GitHub:', error);
        }
    }
});